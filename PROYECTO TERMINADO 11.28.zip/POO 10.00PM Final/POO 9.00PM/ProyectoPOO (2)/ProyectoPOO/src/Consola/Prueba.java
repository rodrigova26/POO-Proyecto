/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Consola;

import java.util.Scanner; 
import Clases.*;          

public class Prueba {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); 

        Eleccion eleccion = new Eleccion();             
        MesaElectoral mesa = new MesaElectoral();       
        ActaElectoral acta = new ActaElectoral();       

        boolean salir = false;

        while (!salir) {
            // Menú principal
            System.out.println("\n=== MENÚ ===");
            System.out.println("1. Registrar Partido Político");    
            System.out.println("2. Registrar Candidato");            
            System.out.println("3. Registrar Mesa y Miembros");      
            System.out.println("4. Ver Información de Mesas");       
            System.out.println("5. Ver Candidatos Registrados");     
            System.out.println("6. Salir");                         
            System.out.println("7. Registrar Votos");                
            System.out.print("Opción: ");

            String opcion = sc.nextLine(); 

            switch (opcion) {
                case "1":
                    eleccion.registrarPartido(); 
                    break;
                case "2":
                    eleccion.registrarCandidato(); 
                    break;
                case "3":
                    mesa.agregarMesasPorTeclado(); 
                    break;
                case "4":
                    mesa.verInfo(); 
                    break;
                case "5":
                    eleccion.mostrarCandidatos(); 
                    break;
                case "6":
                    salir = true; 
                    System.out.println("Fin del Programa");
                    break;
                case "7":
                    acta.registrarVotos(); 
                    break;
                default:
                    System.out.println("Error, intente nuevamente");
            }
        }
    }
}