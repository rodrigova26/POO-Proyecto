/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import java.util.Scanner;

public class ActaElectoral {

    // Atributos básicos de un acta electoral
    private String numeroActa;                // Número identificador del acta                      // Fecha en la que se realiza el acta
    private String idMesa;                    // ID o código de la mesa de votación
    private int totalVotosEmitidos;           // Total de votos emitidos en general
    private int totalVotosBlanco;             // Total de votos en blanco
    private int totalVotosNulos;              // Total de votos nulos
    private String observaciones;             // Comentarios adicionales o incidencias

    // Arrays para manejar candidatos y sus votos
    private Candidato[] candidatos;           // Lista de candidatos (puede no usarse directamente si se usa Eleccion)
    private int[] votosCandidatos;            // Array donde se almacenan los votos por cada candidato

    // Constantes y estructura para votos preferenciales
    private final int MAX_PREFERENCIAS = 3;   // Máximo de preferencias que puede marcar un votante
    private final int MAX_VOTANTES = 100;     // Máximo de votantes que pueden participar
    private int[][] votosPreferenciales = new int[MAX_VOTANTES][MAX_PREFERENCIAS]; // Matriz que almacena votos preferenciales
    private int contadorVotantesPreferenciales = 0; // Lleva la cuenta de cuántos votantes emitieron voto preferencial

    private Eleccion eleccion;                // Objeto Eleccion que administra los candidatos
    Scanner sc = new Scanner(System.in);      // Scanner para leer datos del usuario

    // Constructor vacío: inicializa los datos y registra los candidatos desde la clase Eleccion
    public ActaElectoral() {
        this.eleccion = new Eleccion();
        this.eleccion.registrarCandidato();  // Registra candidatos desde Eleccion (lo hace automáticamente al iniciar)
        this.mostrarCandidatos();            // Muestra en consola los candidatos registrados
        // Crea una nueva fecha (debería pedirse o generarse)
        this.numeroActa = "";
        this.idMesa = "";
        this.totalVotosEmitidos = 0;
        this.totalVotosBlanco = 0;
        this.totalVotosNulos = 0;
        this.observaciones = "";
    }

    // Constructor completo: Permite crear un acta electoral con todos los datos cargados
    public ActaElectoral(String numeroActa, String idMesa, int totalVotosEmitidos, int totalVotosBlanco,
                         int totalVotosNulos, String observaciones, Candidato[] candidatos, int[] votosCandidatos) {

        this.numeroActa = numeroActa;
        this.idMesa = idMesa;
        this.totalVotosEmitidos = totalVotosEmitidos;
        this.totalVotosBlanco = totalVotosBlanco;
        this.totalVotosNulos = totalVotosNulos;
        this.observaciones = observaciones;
        this.candidatos = candidatos;
        this.votosCandidatos = new int[candidatos.length]; // Inicializa el array de votos según la cantidad de candidatos
    }

    // Método para registrar votos por un candidato
    public void registrarVotos() {

        // Obtiene los candidatos registrados en la Elección
        Candidato[] candidatosEleccion = eleccion.getCandidatos();

        // Si no hay candidatos, no se puede continuar
        if (candidatosEleccion.length == 0) {
            System.out.println("Error: Aún no hay candidatos registrados.");
            return;
        }

        // Muestra la lista de candidatos disponibles para votar
        System.out.println("------ REGISTRAR VOTOS ------");
        System.out.println("Por favor seleccione el candidato para registrar sus votos:");

        for (int i = 0; i < candidatosEleccion.length; i++) {
            if (candidatosEleccion[i] != null) {
                System.out.println((i + 1) + ". " + candidatosEleccion[i].getNombre() + " " + candidatosEleccion[i].getApellido() + 
                                   " - DNI: " + candidatosEleccion[i].getDni());
            }
        }

        // Solicita al usuario el número del candidato al que se le quiere registrar votos
        System.out.print("Ingrese el número del candidato (1 - " + candidatosEleccion.length + "): ");
        int option = sc.nextInt();

        // Valida que la opción sea correcta
        if (option < 1 || option > candidatosEleccion.length) {
            System.out.println("Error: opción inválida.");
            return;
        }

        // Obtiene el índice real (arreglos empiezan en 0)
        int candidatoIndex = option - 1;
        Candidato candidatoSeleccionado = candidatosEleccion[candidatoIndex];

        // Solicita al usuario la cantidad de votos que quiere registrar para ese candidato
        System.out.print("Ingrese la cantidad de votos para " + candidatoSeleccionado.getNombre() + ": ");
        int votos = sc.nextInt();

        // Valida que los votos sean positivos
        if (votos < 1) {
            System.out.println("Error: un candidato debe tener al menos 1 voto.");
            return;
        }

        // Actualiza los votos del candidato y el total de votos emitidos
        votosCandidatos[candidatoIndex] += votos;
        totalVotosEmitidos += votos;

        // Muestra el resultado actualizado
        System.out.println("Votos registrados correctamente para " + candidatoSeleccionado.getNombre() + ".");
        System.out.println("Total de votos para " + candidatoSeleccionado.getNombre() + " " + candidatoSeleccionado.getApellido() + 
                           ": " + votosCandidatos[candidatoIndex]);
        System.out.println("Total de votos emitidos (incluye blancos y nulos): " + (totalVotosEmitidos + totalVotosBlanco + totalVotosNulos));
    }

    // Devuelve los candidatos registrados desde la Eleccion
    public Candidato[] getCandidatos() {
        return eleccion != null ? eleccion.getCandidatos() : new Candidato[0];
    }

    // Muestra en consola los nombres de los candidatos registrados
    public void mostrarCandidatos() {
        for (Candidato c : getCandidatos()) {
            if (c != null) {
                System.out.println(c.getNombre() + " " + c.getApellido());
            }
        }
    }
}
