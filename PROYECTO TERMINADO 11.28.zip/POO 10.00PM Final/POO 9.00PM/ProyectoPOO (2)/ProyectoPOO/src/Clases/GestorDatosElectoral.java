/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author Lenovo
 */
public class GestorDatosElectoral {
    // Instancia de la Eleccion actual que se está gestionando en el sistema.
    // Eleccion es responsable de sus propios candidatos y partidos.
    private Eleccion eleccionActual;

    // Datos de las mesas electorales, si son globales al sistema y no parte de 'Eleccion'.
    private MiembroMesa[][] mesas = new MiembroMesa[10][3]; // Máximo 10 mesas, cada una con 3 miembros
    private int cantidadMesas = 0;

    // Constructor: Inicializa los datos del sistema.
    public GestorDatosElectoral() {
        this.eleccionActual = new Eleccion(); // Crea una Eleccion por defecto al iniciar el gestor.
    }

    // --- Métodos para gestionar la Eleccion actual ---
    public Eleccion getEleccionActual() {
        return eleccionActual;
    }

    public void setEleccionActual(Eleccion eleccionActual) {
        this.eleccionActual = eleccionActual;
    }

    // --- Métodos para gestionar las Mesas Electorales (si son globales) ---
    public MiembroMesa[][] getMesas() {
        return mesas;
    }

    public void setMesas(MiembroMesa[][] mesas) {
        this.mesas = mesas;
    }

    public int getCantidadMesas() {
        return cantidadMesas;
    }

    public void setCantidadMesas(int cantidadMesas) {
        this.cantidadMesas = cantidadMesas;
    }

    // Lógica de negocio para añadir/eliminar mesas (ahora centralizada aquí)
    public void addMesa(MiembroMesa[] nuevaMesa) {
        if (this.cantidadMesas < 10) {
            this.mesas[this.cantidadMesas++] = nuevaMesa;
        } else {
            System.out.println("Límite de mesas alcanzado. No se puede añadir más."); // Mensaje para consola
        }
    }

    public void removeLastMesa() {
        if (this.cantidadMesas > 0) {
            this.cantidadMesas--;
            this.mesas[this.cantidadMesas] = null; // Limpiar la referencia para GC
        } else {
            System.out.println("No hay mesas para eliminar."); // Mensaje para consola
        }
    }
}
