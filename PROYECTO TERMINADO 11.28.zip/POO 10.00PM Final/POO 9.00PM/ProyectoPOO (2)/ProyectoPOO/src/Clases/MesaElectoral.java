/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;
import java.util.Scanner;

public class MesaElectoral {

    private MiembroMesa[][] arregloMiembros;   
    private String idMesa;
    private int cantidadMesas;  
    private static final int MAX = 10;  
    private static final int MAX_MIEMBROS = 3;  

    //----CONSTRUCTOR SIN PARAMETROS---//
    public MesaElectoral() {
        idMesa = "";
        cantidadMesas = 0;

        arregloMiembros = new MiembroMesa[MAX][MAX_MIEMBROS];  //ARREGLO PARA ALMACENAR HASTA 10 MESAS, CADA UNA CON 3 MIEMBROS
    }

    //------CONSTRUCTOR CON PARAMETOS-----//
    public MesaElectoral(String idMesa) {
        this.idMesa = idMesa;

        this.cantidadMesas = 0;
        arregloMiembros = new MiembroMesa[MAX][MAX_MIEMBROS];  // Arreglo para almacenar hasta 10 mesas, cada una con 3 miembros
    }

    // METODOS
    public String getIdMesa() {
        return idMesa;
    }

    public void setIdMesa(String idMesa) {
        this.idMesa = idMesa;
    }



    public MiembroMesa[][] getArregloMiembros() {
        return arregloMiembros;
    }

    public int getCantidadMesas() {
        return cantidadMesas;
    }

    // METODOS PARA AGREGAR MESAS Y SUS MIEMBROS POR TECLADO
    public void agregarMesasPorTeclado() {
        Scanner scanner = new Scanner(System.in);

        //BUCLE PARA CREAR LAS MESAS PERO HASTA EL MAX(10)
        for (int i = 0; i < MAX; i++) {
            System.out.println("Ingrese los datos para la mesa #" + (i + 1));

            // CREAR LA MESA CON 3 MIEMBROS
            MiembroMesa[] miembrosMesa = new MiembroMesa[MAX_MIEMBROS];
            for (int j = 0; j < MAX_MIEMBROS; j++) {
                System.out.println("Miembro #" + (j + 1));
                miembrosMesa[j] = MiembroMesa.crearMiembro();  // CREAR MIEMBROS POR TECLADO
            }

            // ASIGNAR LOS MIEMBROS DE MESA AL ARREGLO DE MESAS
            agregarMesa(miembrosMesa);

            // PREGUNTA SI DESEA AGREGAR UNA MESA MAS
            System.out.print("¿Desea agregar otra mesa? (s/n): ");
            String respuesta = scanner.nextLine();//LEE LA RESPUESTA
            if (respuesta.equalsIgnoreCase("n")) {//PARA EVITAR PROBLEMAS SI EL USUARIO PONE (N o n)
                break;//SALIR DEL BUCLE
            }
        }
    }

    // METODO PARA AGREGAR UNA MESA CON SUS MIEMBROS
    public void agregarMesa(MiembroMesa[] miembrosMesa) {
        if (cantidadMesas < MAX) {
            arregloMiembros[cantidadMesas] = miembrosMesa;  // ASIGNAR MESA CON SUS MIEMBROS (EN ESTE CASO 3) 
            cantidadMesas++;
        } else {
            System.out.println("No se pueden agregar más mesas. Limite alcanzado de " + MAX + " mesas.");
        }
    }

    // METODO PARA MOSTRAR LA INFO
    public void verInfo() {
        System.out.println("Mesas del sistema:");
        for (int i = 0; i < cantidadMesas; i++) {
            System.out.println("Mesa #" + (i + 1) + " - ID: " + idMesa + ", Fecha: " );
            System.out.println("Miembros asignados:");
            for (int j = 0; j < MAX_MIEMBROS; j++) {
                arregloMiembros[i][j].verInfo();  // MOSTRAR INFO DE CADA MIEMBROS MESA
            }
        }
    }
}
