/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;


public class Candidato extends Persona {

    private PartidoPolitico partidoPolitico;  // El partido político al que pertenece el candidato
    private int votosEmitidos;                // Cantidad de votos que ha recibido el candidato
    private int votosBlancos;                 // Cantidad de votos en blanco (puede ser por mesa, depende cómo lo uses)
    private int votosNulos;                   // Cantidad de votos nulos (mal emitidos, ilegibles, etc.)

    /**
     * Constructor por defecto:
     * Inicializa el candidato con un partido vacío y los contadores de votos en 0.
     */
    public Candidato() {
        super();  // Llama al constructor vacío de Persona
        partidoPolitico = new PartidoPolitico();  // Se inicializa un partido vacío
        votosEmitidos = 0;
        votosBlancos = 0;
        votosNulos = 0;
    }

    /**
     * Constructor con parámetros:
     * Permite crear un candidato con su nombre, apellido, DNI y partido político.
     */
    public Candidato(String nombre, String apellido, String dni, PartidoPolitico partidoPolitico) {
        super(nombre, apellido, dni);  // Llama al constructor de Persona
        this.partidoPolitico = partidoPolitico;
        this.votosEmitidos = 0;
        this.votosBlancos = 0;
        this.votosNulos = 0;
    }

    // --- Métodos Getter y Setter para el partido político ---

    public PartidoPolitico getPartidoPolitico() {
        return partidoPolitico;
    }

    public void setPartidoPolitico(PartidoPolitico partidoPolitico) {
        this.partidoPolitico = partidoPolitico;
    }

    // --- Métodos para manejar los votos ---

    /**
     * Devuelve la cantidad de votos recibidos por el candidato.
     */
    public int getVotos() {
        return votosEmitidos;
    }

    /**
     * Establece la cantidad de votos recibidos por el candidato.
     */
    public void setVotos(int votosEmitidos) {
        this.votosEmitidos = votosEmitidos;
    }

    /**
     * Devuelve la cantidad de votos en blanco.
     */
    public int getBlancos() {
        return votosBlancos;
    }

    /**
     * Establece la cantidad de votos en blanco.
     */
    public void setBlancos(int votosBlancos) {
        this.votosBlancos = votosBlancos;
    }

    /**
     * Devuelve la cantidad de votos nulos.
     */
    public int getNulos() {
        return votosNulos;
    }

    /**
     * Establece la cantidad de votos nulos.
     */
    public void setNulos(int votosNulos) {
        this.votosNulos = votosNulos;
    }

    // --- Mostrar información del candidato ---

    /**
     * Muestra la información básica del candidato, incluyendo su partido político.
     * Sobrescribe el método verInfo() de Persona.
     */
    @Override
    public void verInfo() {
        super.verInfo();  // Muestra la información heredada de Persona (nombre, apellido, etc.)
        System.out.println("\tPartido: " + partidoPolitico.getNombre());  // Muestra el nombre del partido político
    }
}
