/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;


public class PartidoPolitico {


    private String nombre;
    private String sigla;
    private Persona representanteLegal; 

 
    
    public PartidoPolitico(String nombre, String sigla, Persona representanteLegal) {
        this.nombre = nombre;
        this.sigla = sigla;
        this.representanteLegal = representanteLegal;
    }

    public PartidoPolitico() {
        nombre = "";
        sigla = "";
        representanteLegal = new Persona();
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getSigla() {
        return sigla;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    public Persona getRepresentanteLegal() {
        return representanteLegal;
    }

    public void setRepresentanteLegal(Persona representanteLegal) {
        this.representanteLegal = representanteLegal;
    }

    public String mostrarInfo() {
    return "Partido: " + nombre + " (" + sigla + ")\n" +
        "Representante legal: " + representanteLegal.getNombre() + " " + representanteLegal.getApellido();
}

}