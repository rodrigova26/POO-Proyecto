/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;


public class Candidato extends Persona {

    private PartidoPolitico partidoPolitico; 
    private int votosEmitidos;               
    private int votosBlancos;               
    private int votosNulos;                   


    public Candidato() {
        super();  
        partidoPolitico = new PartidoPolitico();  
        votosEmitidos = 0;
        votosBlancos = 0;
        votosNulos = 0;
    }


    public Candidato(String nombre, String apellido, String dni, PartidoPolitico partidoPolitico) {
        super(nombre, apellido, dni); 
        this.partidoPolitico = partidoPolitico;
        this.votosEmitidos = 0;
        this.votosBlancos = 0;
        this.votosNulos = 0;
    }


    public PartidoPolitico getPartidoPolitico() {
        return partidoPolitico;
    }

    public void setPartidoPolitico(PartidoPolitico partidoPolitico) {
        this.partidoPolitico = partidoPolitico;
    }

 
 
    public int getVotos() {
        return votosEmitidos;
    }

  
    public void setVotos(int votosEmitidos) {
        this.votosEmitidos = votosEmitidos;
    }

   
    public int getBlancos() {
        return votosBlancos;
    }

 
    public void setBlancos(int votosBlancos) {
        this.votosBlancos = votosBlancos;
    }


    public int getNulos() {
        return votosNulos;
    }


    public void setNulos(int votosNulos) {
        this.votosNulos = votosNulos;
    }


    @Override
    public void verInfo() {
        super.verInfo(); 
        System.out.println("\tPartido: " + partidoPolitico.getNombre());  
    }
}
