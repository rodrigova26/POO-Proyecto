/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Clases;
import javax.swing.JOptionPane;
import Clases.*;


public class VentanaMenu extends javax.swing.JFrame {
    
    private Eleccion eleccion;
    private MiembroMesa[][] mesas = new MiembroMesa[10][3];
    private int cantidadMesas = 0;
 
    public VentanaMenu() {
        initComponents();
        this.eleccion = new Eleccion();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        botonVerResultado = new javax.swing.JButton();
        botonCerrarSesion = new javax.swing.JButton();
        textMenu = new javax.swing.JLabel();
        botonResgistrarPartido = new javax.swing.JButton();
        botonRegistrarCandidato = new javax.swing.JButton();
        botonVerCandidato = new javax.swing.JButton();
        botonEliminarCandidato = new javax.swing.JButton();
        BotonRegistrarVotos = new javax.swing.JButton();
        botonRegistrarMiembroMesa = new javax.swing.JButton();
        botonVerMiembroMesa = new javax.swing.JButton();
        botonEliminarMiembroMesa = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        botonVerResultado.setText("Ver resultados");
        botonVerResultado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVerResultadoActionPerformed(evt);
            }
        });

        botonCerrarSesion.setForeground(new java.awt.Color(255, 102, 102));
        botonCerrarSesion.setText("Cerrar sesion");
        botonCerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCerrarSesionActionPerformed(evt);
            }
        });

        textMenu.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        textMenu.setText("Menú");

        botonResgistrarPartido.setText("Registrar Partido");
        botonResgistrarPartido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonResgistrarPartidoActionPerformed(evt);
            }
        });

        botonRegistrarCandidato.setText("Registrar Candidato");
        botonRegistrarCandidato.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonRegistrarCandidatoActionPerformed(evt);
            }
        });

        botonVerCandidato.setText("Ver Candidato");
        botonVerCandidato.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVerCandidatoActionPerformed(evt);
            }
        });

        botonEliminarCandidato.setText("Eliminar Candidato");
        botonEliminarCandidato.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarCandidatoActionPerformed(evt);
            }
        });

        BotonRegistrarVotos.setText("Registrar votos");
        BotonRegistrarVotos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonRegistrarVotosActionPerformed(evt);
            }
        });

        botonRegistrarMiembroMesa.setText("Regisrar Miembro Mesa");
        botonRegistrarMiembroMesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonRegistrarMiembroMesaActionPerformed(evt);
            }
        });

        botonVerMiembroMesa.setText("Ver Miembro Mesa");
        botonVerMiembroMesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVerMiembroMesaActionPerformed(evt);
            }
        });

        botonEliminarMiembroMesa.setText("Eliminar Miembro Mesa");
        botonEliminarMiembroMesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarMiembroMesaActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setText("Elecciones");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel2.setText("Mesa Electoral");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(botonEliminarCandidato, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(botonVerCandidato, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(botonRegistrarCandidato, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(botonResgistrarPartido, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(botonCerrarSesion, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(BotonRegistrarVotos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(botonVerResultado, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(textMenu)
                                .addGap(16, 16, 16)))
                        .addGap(98, 98, 98)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(botonRegistrarMiembroMesa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(botonVerMiembroMesa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(botonEliminarMiembroMesa, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(74, 74, 74))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(textMenu)
                        .addGap(34, 34, 34))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(botonResgistrarPartido)
                    .addComponent(botonRegistrarMiembroMesa))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(botonRegistrarCandidato)
                    .addComponent(botonVerMiembroMesa))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(botonVerCandidato)
                        .addGap(18, 18, 18)
                        .addComponent(botonEliminarCandidato))
                    .addComponent(botonEliminarMiembroMesa))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addComponent(BotonRegistrarVotos)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(botonVerResultado)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(botonCerrarSesion)
                .addGap(26, 26, 26))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonVerCandidatoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVerCandidatoActionPerformed
        verCandidatos();
    }//GEN-LAST:event_botonVerCandidatoActionPerformed

    private void botonCerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCerrarSesionActionPerformed
  
        int confirmacion = JOptionPane.showConfirmDialog(
            this,
            "¿Está seguro que desea cerrar sesión?",
            "Confirmar cierre de sesión",
            JOptionPane.YES_NO_OPTION
        );

        if (confirmacion == JOptionPane.YES_OPTION) {
            this.dispose(); 
            new VentanaLogin().setVisible(true); 
        }
    }//GEN-LAST:event_botonCerrarSesionActionPerformed

    private void botonVerResultadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVerResultadoActionPerformed
        verVotos();
    }//GEN-LAST:event_botonVerResultadoActionPerformed

    private void botonResgistrarPartidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonResgistrarPartidoActionPerformed
        registrarPartido();
    }//GEN-LAST:event_botonResgistrarPartidoActionPerformed

    private void botonRegistrarCandidatoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonRegistrarCandidatoActionPerformed
        registrarCandidato();
    }//GEN-LAST:event_botonRegistrarCandidatoActionPerformed

    private void botonEliminarCandidatoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarCandidatoActionPerformed
        eliminarCandidato();
    }//GEN-LAST:event_botonEliminarCandidatoActionPerformed

    private void botonRegistrarMiembroMesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonRegistrarMiembroMesaActionPerformed
        registrarMiembroMesa();
    }//GEN-LAST:event_botonRegistrarMiembroMesaActionPerformed

    private void botonVerMiembroMesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVerMiembroMesaActionPerformed
        verMiembrosMesa();
    }//GEN-LAST:event_botonVerMiembroMesaActionPerformed

    private void botonEliminarMiembroMesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarMiembroMesaActionPerformed
        eliminarMiembroMesa();
    }//GEN-LAST:event_botonEliminarMiembroMesaActionPerformed

    private void BotonRegistrarVotosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonRegistrarVotosActionPerformed
        registrarVotos();
    }//GEN-LAST:event_BotonRegistrarVotosActionPerformed
    
    

    private void registrarPartido() {
        String nombre = JOptionPane.showInputDialog("Nombre del Partido:");
        String sigla = JOptionPane.showInputDialog("Sigla del Partido:");
        String nombreRep = JOptionPane.showInputDialog("Nombre del Representante:");
        String apellidoRep = JOptionPane.showInputDialog("Apellido del Representante:");
        String dniRep = JOptionPane.showInputDialog("DNI del Representante:");

        Persona representante = new Persona(nombreRep, apellidoRep, dniRep);
        PartidoPolitico partido = new PartidoPolitico(nombre, sigla, representante);

        if (eleccion.getCantidadPartidos() < 20) {
            eleccion.getPartidos()[eleccion.getCantidadPartidos()] = partido;
            eleccion.setCantidadPartidos(eleccion.getCantidadPartidos() + 1);
            JOptionPane.showMessageDialog(this, "Partido registrado correctamente");
        } else {
            JOptionPane.showMessageDialog(this, "No se pueden registrar más partidos");
        }
    }


    private void registrarCandidato() {
        if (eleccion.getCantidadPartidos() == 0) {
            JOptionPane.showMessageDialog(this, "Debe registre un partido primero");
            return;
        }

        String nombre = JOptionPane.showInputDialog("Nombre del Candidato:");
        String apellido = JOptionPane.showInputDialog("Apellido del Candidato:");
        String dni = JOptionPane.showInputDialog("DNI del Candidato:");

 
        String lista = "";
        for (int i = 0; i < eleccion.getCantidadPartidos(); i++) {
            lista += (i + 1) + ". " + eleccion.getPartidos()[i].getNombre() + "\n";
        }

        int opcion = Integer.parseInt(JOptionPane.showInputDialog("Seleccione el partido:\n" + lista)) - 1;
        PartidoPolitico partido = eleccion.getPartidos()[opcion];

        Candidato nuevo = new Candidato(nombre, apellido, dni, partido);

  
        Candidato[] nuevoArray = new Candidato[eleccion.getCandidatos().length + 1];
        for (int i = 0; i < eleccion.getCandidatos().length; i++) {
            nuevoArray[i] = eleccion.getCandidatos()[i];
        }
        nuevoArray[eleccion.getCandidatos().length] = nuevo;

        eleccion.setCandidatos(nuevoArray);
        eleccion.setCantidadCandidatos(eleccion.getCantidadCandidatos() + 1);

        JOptionPane.showMessageDialog(this, "Candidato registrado correctamente");
    }

    
    private void verCandidatos() {
        if (eleccion.getCantidadCandidatos() == 0) {
            JOptionPane.showMessageDialog(this, "No hay candidatos");
            return;
        }

        StringBuilder lista = new StringBuilder();
        for (int i = 0; i < eleccion.getCantidadCandidatos(); i++) {
            Candidato c = eleccion.getCandidatos()[i];
            lista.append((i + 1)).append(". ")
                 .append(c.getNombre()).append(" ").append(c.getApellido())
                 .append(" - Partido: ").append(c.getPartidoPolitico().getNombre()).append("\n");
        }

        JOptionPane.showMessageDialog(this, lista.toString());
    }

 
    private void eliminarCandidato() {
        if (eleccion.getCantidadCandidatos() == 0) {
            JOptionPane.showMessageDialog(this, "No hay candidatos");
            return;
        }

        StringBuilder lista = new StringBuilder();
        for (int i = 0; i < eleccion.getCantidadCandidatos(); i++) {
            Candidato c = eleccion.getCandidatos()[i];
            lista.append((i + 1)).append(". ").append(c.getNombre()).append(" ").append(c.getApellido()).append("\n");
        }

        int opcion = Integer.parseInt(JOptionPane.showInputDialog("Seleccione el candidato a eliminar: (Seleccionar número)\n" + lista)) - 1;

        Candidato[] nuevoArray = new Candidato[eleccion.getCandidatos().length - 1];
        int index = 0;
        for (int i = 0; i < eleccion.getCandidatos().length; i++) {
            if (i != opcion) {
                nuevoArray[index++] = eleccion.getCandidatos()[i];
            }
        }

        eleccion.setCandidatos(nuevoArray);
        eleccion.setCantidadCandidatos(eleccion.getCantidadCandidatos() - 1);
        JOptionPane.showMessageDialog(this, "Candidato eliminado");
    }

   
    private void registrarMiembroMesa() {
        if (cantidadMesas >= 10) {
            JOptionPane.showMessageDialog(this, "Límite de mesas alcanzado");
            return;
        }

        for (int j = 0; j < 3; j++) {
            String nombre = JOptionPane.showInputDialog("Nombre del Miembro " + (j + 1));
            String apellido = JOptionPane.showInputDialog("Apellido del Miembro " + (j + 1));
            String dni = JOptionPane.showInputDialog("DNI del Miembro " + (j + 1));
            String[] roles = {"Presidente", "Secretario", "Vocal"};
            String tipo = (String) JOptionPane.showInputDialog(this, "Tipo:", "Tipo", JOptionPane.QUESTION_MESSAGE, null, roles, roles[0]);
            mesas[cantidadMesas][j] = new MiembroMesa(nombre, apellido, dni, tipo);
        }
        cantidadMesas++;
        JOptionPane.showMessageDialog(this, "Mesa registrada exitosamente");
    }

  
    private void verMiembrosMesa() {
        if (cantidadMesas == 0) {
            JOptionPane.showMessageDialog(this, "No hay mesas");
            return;
        }

        StringBuilder texto = new StringBuilder();
        for (int i = 0; i < cantidadMesas; i++) {
            texto.append("Mesa ").append(i + 1).append(":\n");
            for (int j = 0; j < 3; j++) {
                MiembroMesa mesa = mesas[i][j];
                texto.append("- ").append(mesa.getNombre()).append(" ").append(mesa.getApellido()).append(" (").append(mesa.getTipoMiembro()).append(")\n");
            }
            texto.append("\n");
        }

        JOptionPane.showMessageDialog(this, texto.toString());
    }

   
    private void eliminarMiembroMesa() {
        if (cantidadMesas == 0) {
            JOptionPane.showMessageDialog(this, "No hay mesas para eliminar");
            return;
        }

        cantidadMesas--;
        mesas[cantidadMesas] = new MiembroMesa[3];
        JOptionPane.showMessageDialog(this, "Última mesa eliminada");
    }

   
    private void registrarVotos() {
        for (int i = 0; i < eleccion.getCantidadCandidatos(); i++) {
            Candidato c = eleccion.getCandidatos()[i];
            try {
                int emitidos = Integer.parseInt(JOptionPane.showInputDialog("Votos emitidos para " + c.getNombre()));
                int blancos = Integer.parseInt(JOptionPane.showInputDialog("Votos blancos para " + c.getNombre()));
                int nulos = Integer.parseInt(JOptionPane.showInputDialog("Votos nulos para " + c.getNombre()));
                c.setVotos(c.getVotos() + emitidos);
                c.setBlancos(c.getBlancos() + blancos);
                c.setNulos(c.getNulos() + nulos);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Datos inválidos. Se omitió");
            }
        }
        JOptionPane.showMessageDialog(this, "Votos registrados exitosamente");
    }


    private void verVotos() {
        StringBuilder resultado = new StringBuilder("Resultados de votos por Partido \n");
        for (int i = 0; i < eleccion.getCantidadPartidos(); i++) {
            PartidoPolitico partido = eleccion.getPartidos()[i];
            int votos = 0, blancos = 0, nulos = 0;

            for (Candidato c : eleccion.getCandidatos()) {
                if (c.getPartidoPolitico().getNombre().equals(partido.getNombre())) {
                    votos += c.getVotos();
                    blancos += c.getBlancos();
                    nulos += c.getNulos();
                }
            }

            int total = votos + blancos + nulos;
            resultado.append("Partido: ").append(partido.getNombre()).append("\n")
                     .append("  Emitidos: ").append(votos).append("\n")
                     .append("  Blancos: ").append(blancos).append("\n")
                     .append("  Nulos: ").append(nulos).append("\n")
                     .append("  TOTAL: ").append(total).append("\n\n");
        }

        JOptionPane.showMessageDialog(this, resultado.toString());
    }
    
    
    public static void main(String args[]) {
       
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonRegistrarVotos;
    private javax.swing.JButton botonCerrarSesion;
    private javax.swing.JButton botonEliminarCandidato;
    private javax.swing.JButton botonEliminarMiembroMesa;
    private javax.swing.JButton botonRegistrarCandidato;
    private javax.swing.JButton botonRegistrarMiembroMesa;
    private javax.swing.JButton botonResgistrarPartido;
    private javax.swing.JButton botonVerCandidato;
    private javax.swing.JButton botonVerMiembroMesa;
    private javax.swing.JButton botonVerResultado;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel textMenu;
    // End of variables declaration//GEN-END:variables
}
