/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import java.util.Scanner;
public class MiembroMesa extends Persona{


    private String tipoMiembro;
    
    

    public MiembroMesa() {
        super();
        tipoMiembro = "";
    }
    public MiembroMesa(String nombre, String apellido, String dni, String tipoMiembro){
        super(nombre, apellido, dni);
        this.tipoMiembro = tipoMiembro;
    }

    public String getTipoMiembro() {
        return tipoMiembro;
    }
    
    public void setTipoMiembro(String tipoMiembro) {
        this.tipoMiembro = tipoMiembro;
    }

        public static MiembroMesa crearMiembro() {
        Scanner scanner = new Scanner(System.in);


        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Apellido: ");
        String apellido = scanner.nextLine();

        System.out.print("DNI: ");
        String dni = scanner.nextLine();

        System.out.print("Tipo de miembro (Presidente, Secretario, Vocal): ");
        String tipo = scanner.nextLine();

        return new MiembroMesa(nombre, apellido, dni, tipo);
    }
    
    @Override
    public void verInfo(){
        super.verInfo();
        System.out.println("\tTipo de Miembro:\t" +tipoMiembro);
    }    
}
