/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import java.util.ArrayList;

import proyectopoo.ListaPartido;
import proyectopoo.partidoPolitico;
import proyectopoo.Candidato;
import proyectopoo.ListaCandidato;

/**
 *
 * @author Carlos
 */
public class ControladorPartido {
    private ListaPartido modelo;
    private ControladorCandidato controladorCandidato; 
    public ControladorPartido() {
        this.modelo = new ListaPartido();
    }
    public ControladorPartido(ControladorCandidato controladorCandidato) {
        this.modelo = new ListaPartido();
        this.controladorCandidato = controladorCandidato;
    }

    public boolean agregar(partidoPolitico partidoPolitico) {
        return this.modelo.agregar(partidoPolitico);
    }
    public boolean eliminar(partidoPolitico partidoPolitico) {
        return this.modelo.eliminar(partidoPolitico);
    }
    
    public ArrayList<partidoPolitico> getListaPartidos() {
        return this.modelo.getListaPartidos();
    }
    
    public ArrayList<partidoPolitico> getTodosLosPartidos() {
    return partidoPolitico.getTodosLosPartidos(); 
    }
    public String obtenerNombrePartidoPorCandidato(Candidato candidato) {
    for (partidoPolitico partido : modelo.getListaPartidos()) {
        if (partido.getListaCandidatos().contains(candidato)) {
            return partido.getNombre(); 
        }
    }
    return "Sin partido";
}
}

  