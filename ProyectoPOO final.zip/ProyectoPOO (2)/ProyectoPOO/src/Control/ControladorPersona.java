/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import java.util.ArrayList;
import proyectopoo.Candidato;
import proyectopoo.ListaPersona;
import proyectopoo.MiembroMesa;
import proyectopoo.Persona;

/**
 *
 * @author Carlos
 */
public class ControladorPersona {
    private ListaPersona modelo;

    public ControladorPersona() {
        modelo = new ListaPersona();
    }

    public boolean agregar(Persona persona) {
        return modelo.agregar(persona);
    }
    
    public ArrayList<Persona> getListaMiembroMesa() {

        ArrayList<Persona> lista = this.modelo.getListaPersonas();
        ArrayList<Persona> MiembroMesa = new ArrayList<>();

        for (Persona persona : lista) {
            if (persona instanceof MiembroMesa) {
                MiembroMesa.add(persona);
            }
        }
        return MiembroMesa;
    }
    
    public ArrayList<Persona> getListaCandidato() {

        ArrayList<Persona> lista = this.modelo.getListaPersonas();
        ArrayList<Persona> Candidato = new ArrayList<>();

        for (Persona persona : lista) {
            if (persona instanceof Candidato) {
                Candidato.add(persona);
            }
        }
        return Candidato;
    }
}
