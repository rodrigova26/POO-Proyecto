package Control;

import java.util.ArrayList;
import proyectopoo.Eleccion;
import proyectopoo.ListaEleccion;
import proyectopoo.MiembroMesa;
import proyectopoo.Persona;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Carlos
 */
public class ControladorEleccion {
    private ListaEleccion modelo;
    
    public ControladorEleccion() {
        this.modelo = new ListaEleccion();
    }

    public boolean agregar(Eleccion Eleccion) {
        return this.modelo.agregar(Eleccion);
    }
    public boolean eliminar(Eleccion eleccion) {
        return this.modelo.eliminar(eleccion);
    }
    
    public ArrayList<Eleccion> getListaElecciones() {
        return this.modelo.getListaElecciones();
    }
    
    public ArrayList<Eleccion> getTodasLasElecciones() {
    return Eleccion.getTodasLasElecciones(); 
}
}
