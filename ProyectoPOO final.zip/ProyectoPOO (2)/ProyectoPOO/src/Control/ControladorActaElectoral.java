/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import java.util.ArrayList;
import proyectopoo.ListaActaElectoral;
import proyectopoo.ActaElectoral;

/**
 *
 * @author Carlos
 */
public class ControladorActaElectoral {
    private ListaActaElectoral modelo;
    
    public ControladorActaElectoral() {
        this.modelo = new ListaActaElectoral();
    }

    public boolean agregar(ActaElectoral ActaElectoral) {
        return this.modelo.agregar(ActaElectoral);
    }
    public boolean eliminar(ActaElectoral ActaElectoral) {
        return this.modelo.eliminar(ActaElectoral);
    }
    
    public ArrayList<ActaElectoral> getListaActasElectorales() {
        return this.modelo.getListaActaElectoral();
    }
    
}
