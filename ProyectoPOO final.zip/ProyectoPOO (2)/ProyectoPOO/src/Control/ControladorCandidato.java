/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;
import proyectopoo.ListaCandidato;
import java.util.ArrayList;
import proyectopoo.Eleccion;
import proyectopoo.ListaEleccion;
import proyectopoo.MiembroMesa;
import proyectopoo.Persona;
import proyectopoo.ListaCandidato;
import proyectopoo.Candidato;

public class ControladorCandidato {
    private ListaCandidato modelo;
    
    public ControladorCandidato() {
        this.modelo = new ListaCandidato();
    }

    public boolean agregar(Candidato Candidato) {
        return this.modelo.agregar(Candidato);
    }
    public boolean eliminar(Candidato Candidato) {
        return this.modelo.eliminar(Candidato);
    }
    
    public ArrayList<Candidato> getListaCandidatos() {
        return this.modelo.getListaCandidatos();
    }
    
    public boolean eliminarPorDNI(String dni) {
    ArrayList<Candidato> lista = modelo.getListaCandidatos();
    for (Candidato c : lista) {
        if (c.getDni().equals(dni)) {
            return modelo.eliminar(c); // Usa el método ya existente en ListaCandidato
        }
    }
    return false;
}
    
    public ArrayList<Candidato> getTodosLosCandidatos() {
    return Candidato.getTodosLosCandidatos(); // accede a la lista persistente
}
}