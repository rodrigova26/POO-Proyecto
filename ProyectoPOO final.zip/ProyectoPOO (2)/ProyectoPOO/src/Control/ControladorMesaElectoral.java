/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import java.util.ArrayList;
import proyectopoo.MesaElectoral;
import proyectopoo.ListaMesaElectoral;

/**
 *
 * @author Carlos
 */
public class ControladorMesaElectoral {
    private ListaMesaElectoral modelo;
    
    public ControladorMesaElectoral() {
        this.modelo = new ListaMesaElectoral();
    }

    public boolean agregar(MesaElectoral MesaElectoral) {
        return this.modelo.agregar(MesaElectoral);
    }
    public boolean eliminar(MesaElectoral MesaElectoral) {
        return this.modelo.eliminar(MesaElectoral);
    }
    
    public ArrayList<MesaElectoral> getListaMesasElectorales() {
        return this.modelo.getListaMesaElectoral();
    }
    
}

