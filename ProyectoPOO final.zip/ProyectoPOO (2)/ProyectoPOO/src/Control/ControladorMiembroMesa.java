/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import java.util.ArrayList;
import proyectopoo.MiembroMesa;
import proyectopoo.ListaMiembroMesa;

/**
 *
 * @author Carlos
 */
public class ControladorMiembroMesa {
    private ListaMiembroMesa modelo;
    
    public ControladorMiembroMesa() {
        this.modelo = new ListaMiembroMesa();
    }

    public boolean agregar(MiembroMesa MiembroMesa) {
        return this.modelo.agregar(MiembroMesa);
    }
    public boolean eliminar(MiembroMesa MiembroMesa) {
        return this.modelo.eliminar(MiembroMesa);
    }
    
    public ArrayList<MiembroMesa> getListaMiembroMesa() {
        return this.modelo.getListaMiembrosMesa();
    }
    
    public ArrayList<MiembroMesa> getTodasLosMiembrosMesa() {
    return MiembroMesa.getTodosLosMiembrosMesa(); 
}
    
    
}
