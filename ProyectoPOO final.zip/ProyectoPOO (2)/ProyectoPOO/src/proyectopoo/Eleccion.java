/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoo;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Rodrigo
 */
public class Eleccion implements Serializable {
    private static ArrayList<Eleccion> todasLasElecciones = new ArrayList<>();
    private String tipo;
    private String fecha;
    private ArrayList<Candidato> candidatos = new ArrayList<>();
    private String nombre;
    
    public Eleccion(String tipo, String fecha, String nombre) {
        this.tipo = tipo;
        this.fecha = fecha;
        this.nombre = nombre;
        todasLasElecciones.add(this);
    }
    
    public void agregarCandidato(Candidato c) {
        candidatos.add(c);
    }

    public boolean eliminarCandidato(Candidato c) {
        return candidatos.remove(c);
    }

    // Getters/Setters
    public ArrayList<Candidato> getCandidatos() { return candidatos; }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    
    public static ArrayList<Eleccion> getTodasLasElecciones() {
        return new ArrayList<>(todasLasElecciones);  
    }
    
    public static void guardarElecciones() {
        try (ObjectOutputStream oos = new ObjectOutputStream(
            new FileOutputStream("elecciones.dat"))) {
            oos.writeObject(todasLasElecciones);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Método para cargar desde archivo (añade esto)
    public static void cargarElecciones() {
        try (ObjectInputStream ois = new ObjectInputStream(
            new FileInputStream("elecciones.dat"))) {
            todasLasElecciones = (ArrayList<Eleccion>) ois.readObject();
        } catch (Exception e) {
            // Si el archivo no existe, inicia vacío
            todasLasElecciones = new ArrayList<>();
        }
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        Eleccion other = (Eleccion) obj;
        return tipo.equals(other.tipo) &&
               fecha.equals(other.fecha) &&
               nombre.equals(other.nombre);
    }

    @Override
    public int hashCode() {
        return java.util.Objects.hash(tipo, fecha, nombre);
    }
    
    @Override
    public String toString() {
    return this.nombre; 
}

}