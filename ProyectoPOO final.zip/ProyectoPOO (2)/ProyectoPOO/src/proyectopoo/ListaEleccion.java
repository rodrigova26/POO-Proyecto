/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoo;
import java.util.ArrayList;
/**
 *
 * @author Carlos
 */
public class ListaEleccion {
    private ArrayList<Eleccion> array;

    public ListaEleccion() {
        this.array = new ArrayList<Eleccion>();
    }
    
    public boolean agregar(Eleccion Eleccion) {
        this.array.add(Eleccion);
        return true;
    }
    
    public boolean eliminar(Eleccion eleccion) {
        return this.array.remove(eleccion);
    }
    

    public ArrayList<Eleccion> getListaElecciones() {
        if (array.isEmpty()) {
            return array;
        }

       
        ArrayList<Eleccion> copia = new ArrayList<Eleccion>();

        
        for (int i = 0; i < array.size(); i++) {
            copia.add(array.get(i)); 
        }

        return copia;
    }
}

