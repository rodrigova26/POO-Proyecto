/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoo;

import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author Rodrigo
 */
public class MiembroMesa extends Persona {
    private String tipo;
    private static ArrayList<MiembroMesa> todosLosMiembrosMesa = new ArrayList<>();

    public MiembroMesa(String tipo, String nombres, String apellidos) {
        super(nombres, apellidos);
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public static ArrayList<MiembroMesa> getTodosLosMiembrosMesa() {
        return new ArrayList<>(todosLosMiembrosMesa);  
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MiembroMesa that = (MiembroMesa) o;

        return tipo.equals(that.tipo) &&
               nombres.equals(that.nombres) &&
               apellidos.equals(that.apellidos);
    }

    @Override
    public int hashCode() {
        return Objects.hash(tipo, nombres, apellidos);
    }
    @Override
    public String toString() {
        return this.getNombres() + " - " + tipo;
    }
}   

