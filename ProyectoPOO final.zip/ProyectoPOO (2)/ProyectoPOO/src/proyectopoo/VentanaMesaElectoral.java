/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyectopoo;

import Control.ControladorActaElectoral;
import Control.ControladorCandidato;
import Control.ControladorEleccion;
import Control.ControladorMesaElectoral;
import Control.ControladorMiembroMesa;
import Control.ControladorPartido;
import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Carlos
 */
public class VentanaMesaElectoral extends javax.swing.JFrame {
    private ControladorMiembroMesa controladorMiembroMesa;
    private ControladorEleccion controlador;
    private ControladorPartido controladorPartido;
    private ControladorCandidato controladorCandidato;
    private ControladorMesaElectoral controladorMesaElectoral;
    private ControladorActaElectoral controladorActaElectoral;
    
    private DefaultComboBoxModel modeloComboEleccion;
    private DefaultComboBoxModel modeloComboPresidente;
    private DefaultComboBoxModel modeloComboSecretario;
    private DefaultComboBoxModel modeloComboVocal;
    
    
    private DefaultTableModel modeloTabla;
    private final String[] COLUMNAS = new String[]{
        "Num", "Presidente", "Secretario", "Vocal","Eleccion"};
    /**
     * Creates new form VentanaMesaElectoral
     */
    public VentanaMesaElectoral() {
        initComponents();
    }
    
    public VentanaMesaElectoral(ControladorEleccion controladors,
    ControladorPartido controladorPartido,
    ControladorCandidato controladorCandidato,
    ControladorMiembroMesa controladorMiembroMesa,ControladorMesaElectoral controladorMesaElectoral, ControladorActaElectoral controladorActaElectoral) {
        initComponents();
        this.controlador = controladors;
        this.controladorPartido = controladorPartido;
        this.controladorCandidato = controladorCandidato;
        this.controladorMiembroMesa = controladorMiembroMesa;
        this.controladorActaElectoral = controladorActaElectoral;
        this.controladorMesaElectoral = controladorMesaElectoral;
        
        modeloComboEleccion = new DefaultComboBoxModel();
        this.cbxEleccion.setModel(modeloComboEleccion);
        
        modeloComboPresidente = new DefaultComboBoxModel();
        this.cbxPresidente.setModel(modeloComboPresidente);
        
        modeloComboSecretario = new DefaultComboBoxModel();
        this.cbxSecretario.setModel(modeloComboSecretario);
        
        modeloComboVocal = new DefaultComboBoxModel();
        this.cbxVocal.setModel(modeloComboVocal);
        
        this.llenarEleccionesEnCombo();
        this.llenarPresidentesEnCombo();
        this.llenarSecretariosEnCombo();
        this.llenarVocalesEnCombo();
        this.inicializarTabla();
        this.actualizarTabla();
        
        
    }
    
     private void llenarEleccionesEnCombo() {
        ArrayList<Eleccion> listaElecciones = controlador.getListaElecciones();
        for (Eleccion Eleccion : listaElecciones) {
            this.modeloComboEleccion.addElement(Eleccion);
        }
    }
    
    
    private void llenarPresidentesEnCombo() {
        modeloComboPresidente.removeAllElements(); 
        ArrayList<MiembroMesa> listaMiembrosMesa = controladorMiembroMesa.getListaMiembroMesa();
    
        for (MiembroMesa miembro : listaMiembrosMesa) {
            if (miembro.getTipo().equalsIgnoreCase("Presidente")) {
                modeloComboPresidente.addElement(miembro);
            }
        }
    }
    private void llenarSecretariosEnCombo() {
        modeloComboSecretario.removeAllElements();
        ArrayList<MiembroMesa> listaMiembrosMesa = controladorMiembroMesa.getListaMiembroMesa();

        for (MiembroMesa miembro : listaMiembrosMesa) {
            if (miembro.getTipo().equalsIgnoreCase("Secretario")) {
                modeloComboSecretario.addElement(miembro);
            }
        }
    }
    
    private void llenarVocalesEnCombo() {
        modeloComboVocal.removeAllElements();
        ArrayList<MiembroMesa> listaMiembrosMesa = controladorMiembroMesa.getListaMiembroMesa();

        for (MiembroMesa miembro : listaMiembrosMesa) {
            if (miembro.getTipo().equalsIgnoreCase("Vocal")) {
                modeloComboVocal.addElement(miembro);
            }
        }
    }
    
    
    private void inicializarTabla() {
        modeloTabla = new DefaultTableModel();
        for (String col : COLUMNAS) {
            modeloTabla.addColumn(col);
        }
        jTable1.setModel(modeloTabla);
    }

    private void actualizarTabla() {
    modeloTabla.setRowCount(0); 

    ArrayList<MesaElectoral> mesas = controladorMesaElectoral.getListaMesasElectorales();

    for (MesaElectoral mesa : mesas) {
        MiembroMesa[] miembros = mesa.getMiembros();

        String presidente = (miembros[0] != null) ? miembros[0].getNombres() : "";
        String secretario = (miembros[1] != null) ? miembros[1].getNombres() : "";
        String vocal = (miembros[2] != null) ? miembros[2].getNombres() : "";

        Object[] fila = {
            mesa.getNumerodeMesa(),
            presidente,
            secretario,
            vocal,
            mesa.getEleccion()
        };

        modeloTabla.addRow(fila);
    }
}

    private void limpiar() {

        this.cbxEleccion.setSelectedIndex(0);
        this.cbxPresidente.setSelectedIndex(0);
        this.cbxSecretario.setSelectedIndex(0);
        this.cbxVocal.setSelectedIndex(0);
        
        
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCheckBox1 = new javax.swing.JCheckBox();
        jLabel1 = new javax.swing.JLabel();
        jNumerodeMesa = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cbxPresidente = new javax.swing.JComboBox<>();
        cbxSecretario = new javax.swing.JComboBox<>();
        cbxVocal = new javax.swing.JComboBox<>();
        cbxEleccion = new javax.swing.JComboBox<>();
        jRegistra = new javax.swing.JButton();
        jCancelar = new javax.swing.JButton();
        jEliminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        jCheckBox1.setText("jCheckBox1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Numero de Mesa :");

        jNumerodeMesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jNumerodeMesaActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Registro de Mesas Electorales");

        jLabel3.setText("Presidente");

        jLabel4.setText("Vocal");

        jLabel5.setText("Secretario");

        jLabel6.setText("Eleccion");

        cbxSecretario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxSecretarioActionPerformed(evt);
            }
        });

        cbxVocal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxVocalActionPerformed(evt);
            }
        });

        jRegistra.setText("Registrar");
        jRegistra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRegistraActionPerformed(evt);
            }
        });

        jCancelar.setText("Cancelar");
        jCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCancelarActionPerformed(evt);
            }
        });

        jEliminar.setText("Eliminar");
        jEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jEliminarActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(76, 76, 76)
                                .addComponent(cbxSecretario, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addGap(15, 15, 15)
                                    .addComponent(jLabel1)
                                    .addGap(29, 29, 29)
                                    .addComponent(jNumerodeMesa, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(120, 120, 120)
                                    .addComponent(jRegistra))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel3)
                                            .addGap(73, 73, 73)
                                            .addComponent(cbxPresidente, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel4)
                                            .addGap(99, 99, 99)
                                            .addComponent(cbxVocal, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jEliminar)
                                        .addComponent(jCancelar)))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(jLabel6)
                                    .addGap(86, 86, 86)
                                    .addComponent(cbxEleccion, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(107, 107, 107)
                        .addComponent(jLabel2)))
                .addContainerGap(46, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jNumerodeMesa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jRegistra))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(cbxPresidente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(13, 13, 13)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(cbxSecretario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(cbxVocal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jEliminar))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jCancelar)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbxEleccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(55, 55, 55)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(55, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jNumerodeMesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jNumerodeMesaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jNumerodeMesaActionPerformed

    private void cbxSecretarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxSecretarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxSecretarioActionPerformed

    private void cbxVocalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxVocalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxVocalActionPerformed

    private void jCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCancelarActionPerformed
        // TODO add your handling code here:
        new VentanaMenu(controlador,
        controladorPartido,
        controladorCandidato,
        controladorMiembroMesa,controladorMesaElectoral,controladorActaElectoral).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jCancelarActionPerformed

    private void jRegistraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRegistraActionPerformed
        
        String numeroMesa = jNumerodeMesa.getText().trim();

        if (numeroMesa.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe ingresar el número de mesa.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        MiembroMesa presidente = (MiembroMesa) cbxPresidente.getSelectedItem();
        MiembroMesa secretario = (MiembroMesa) cbxSecretario.getSelectedItem();
        MiembroMesa vocal = (MiembroMesa) cbxVocal.getSelectedItem();
        Eleccion eleccion = (Eleccion) cbxEleccion.getSelectedItem();

        if (presidente == null || secretario == null || vocal == null || eleccion == null) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar todos los miembros y una elección.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        MesaElectoral nuevaMesa = new MesaElectoral("Lugar no definido", numeroMesa, eleccion.getNombre());
        nuevaMesa.asignarMiembro(presidente);
        nuevaMesa.asignarMiembro(secretario);
        nuevaMesa.asignarMiembro(vocal);

        controladorMesaElectoral.agregar(nuevaMesa);

        JOptionPane.showMessageDialog(this, "Mesa Electoral registrada con éxito.");

        actualizarTabla(); // Si tienes método para refrescar la tabla.
    }//GEN-LAST:event_jRegistraActionPerformed

    private void jEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jEliminarActionPerformed
        // TODO add your handling code here:
        int filaSeleccionada = jTable1.getSelectedRow();

    if (filaSeleccionada >= 0) {
        
        String numeroMesa = modeloTabla.getValueAt(filaSeleccionada, 0).toString();

 
        MesaElectoral mesaAEliminar = null;
        for (MesaElectoral m : controladorMesaElectoral.getListaMesasElectorales()) {
            if (m.getNumerodeMesa().equals(numeroMesa)) {
                mesaAEliminar = m;
                break;
            }
        }

  
        if (mesaAEliminar != null) {
            controladorMesaElectoral.eliminar(mesaAEliminar); 
            modeloTabla.removeRow(filaSeleccionada);
            JOptionPane.showMessageDialog(this, "Mesa eliminada con éxito.");
        } else {
            JOptionPane.showMessageDialog(this, "No se encontró la mesa para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Debe seleccionar una fila.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
    }//GEN-LAST:event_jEliminarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaMesaElectoral.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaMesaElectoral.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaMesaElectoral.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaMesaElectoral.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Eleccion.cargarElecciones(); // Cargar datos persistentes
            ControladorEleccion controlador = new ControladorEleccion();
            ControladorPartido controladorPartido = new ControladorPartido();
            ControladorCandidato controladorCandidato = new ControladorCandidato();
            ControladorMiembroMesa controladorMiembroMesa = new ControladorMiembroMesa();
            ControladorMesaElectoral controladorMesaElectoral = new ControladorMesaElectoral();
            ControladorActaElectoral controladorActaElectoral = new ControladorActaElectoral();

            new VentanaElecciones(controlador, controladorPartido, controladorCandidato, controladorMiembroMesa,controladorMesaElectoral,controladorActaElectoral).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbxEleccion;
    private javax.swing.JComboBox<String> cbxPresidente;
    private javax.swing.JComboBox<String> cbxSecretario;
    private javax.swing.JComboBox<String> cbxVocal;
    private javax.swing.JButton jCancelar;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JButton jEliminar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JTextField jNumerodeMesa;
    private javax.swing.JButton jRegistra;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
