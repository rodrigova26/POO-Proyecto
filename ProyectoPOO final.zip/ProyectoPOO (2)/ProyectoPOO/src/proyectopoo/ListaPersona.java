/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoo;

import java.util.ArrayList;

/**
 *
 * @author Carlos
 */
public class ListaPersona {
    private ArrayList<Persona> array;

    public ListaPersona() {
        this.array = new ArrayList<Persona>();
    }

    public boolean agregar(Persona persona) {
        this.array.add(persona);
        return true;
    }

    public ArrayList<Persona> getListaPersonas() {
        if (array.isEmpty()) {
            return array;
        }

        
        ArrayList<Persona> copia = new ArrayList<Persona>();


        for (int i = 0; i < array.size(); i++) {
            copia.add(array.get(i)); 
        }

        return copia;
    }
}
