/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoo;

import java.util.ArrayList;
/**
 *
 * @author Carlos
 */
public class ListaCandidato {
    private ArrayList<Candidato> array;

    public ListaCandidato() {
        this.array = new ArrayList<Candidato>();
    }
    
    public boolean agregar(Candidato Candidato) {
        this.array.add(Candidato);
        return true;
    }
    
    public boolean eliminar(Candidato Candidato) {
        return this.array.remove(Candidato);
    }
    

    public ArrayList<Candidato> getListaCandidatos() {
        if (array.isEmpty()) {
            return array;
        }

        
        ArrayList<Candidato> copia = new ArrayList<Candidato>();


        for (int i = 0; i < array.size(); i++) {
            copia.add(array.get(i)); 
        }

        return copia;
    }
}