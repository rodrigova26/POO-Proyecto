/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoo;

import java.util.ArrayList;

/**
 *
 * @author Carlos
 */
public class ListaActaElectoral {
    private ArrayList<ActaElectoral> array;

    public ListaActaElectoral() {
        this.array = new ArrayList<ActaElectoral>();
    }
    
    public boolean agregar(ActaElectoral ActaElectoral) {
        this.array.add(ActaElectoral);
        return true;
    }
    
    public boolean eliminar(ActaElectoral ActaElectoral) {
        return this.array.remove(ActaElectoral);
    }
    

    public ArrayList<ActaElectoral> getListaActaElectoral() {
        if (array.isEmpty()) {
            return array;
        }

     
        ArrayList<ActaElectoral> copia = new ArrayList<ActaElectoral>();

        
        for (int i = 0; i < array.size(); i++) {
            copia.add(array.get(i));
        }

        return copia;
    }
}
