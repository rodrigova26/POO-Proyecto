/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoo;

import java.util.ArrayList;

/**
 *
 * @author Carlos
 */
public class ListaMiembroMesa {
    private ArrayList<MiembroMesa> array;

    public ListaMiembroMesa() {
        this.array = new ArrayList<MiembroMesa>();
    }
    
    public boolean agregar(MiembroMesa MiembroMesa) {
        this.array.add(MiembroMesa);
        return true;
    }
    
    public boolean eliminar(MiembroMesa MiembroMesa) {
        return this.array.remove(MiembroMesa);
    }
    

    public ArrayList<MiembroMesa> getListaMiembrosMesa() {
        if (array.isEmpty()) {
            return array;
        }

        
        ArrayList<MiembroMesa> copia = new ArrayList<MiembroMesa>();

        
        for (int i = 0; i < array.size(); i++) {
            copia.add(array.get(i));
        }

        return copia;
    }
}
