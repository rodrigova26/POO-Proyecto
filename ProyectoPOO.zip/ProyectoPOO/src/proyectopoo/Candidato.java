/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoo;

import java.io.Serializable;
import java.util.ArrayList;


public class Candidato extends Persona implements Serializable {
    private String dni;
    private partidoPolitico partido;
    private int votosPreferenciales;
    private String eleccion;
    private static ArrayList<Candidato> todosLosCandidatos = new ArrayList<>();

    public Candidato(String dni, partidoPolitico partido, String nombres, String apellidos,String eleccion) {
        super(nombres, apellidos);
        this.dni = dni;
        this.partido = partido;
        this.votosPreferenciales = 0;
        this.eleccion = eleccion;
    }
    
    public Candidato(String dni, partidoPolitico partido, String nombres, String apellidos) {
        super(nombres, apellidos);
        this.dni = dni;
        this.partido = partido;
        this.votosPreferenciales = 0;
    }
    
    public static ArrayList<Candidato> getTodosLosCandidatos() {
        return new ArrayList<>(todosLosCandidatos);  
    }
    
    public void registrarVotoPreferencial() {
        votosPreferenciales++;
    }

    public String getEleccion() {
        return eleccion;
    }

    public void setEleccion(String eleccion) {
        this.eleccion = eleccion;
    }
    
    

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public partidoPolitico getPartido() {
        return partido;
    }

    public void setPartido(partidoPolitico partido) {
        this.partido = partido;
    }

    public int getVotosPreferenciales() {
        return votosPreferenciales;
    } 
     public String getNombreCompleto() {
        return getNombres() + " " + getApellidos();
    }
     
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        Candidato otro = (Candidato) obj;
        return dni.equals(otro.dni);
    }

    @Override
    public int hashCode() {
        return dni.hashCode(); 
    } 
    
    @Override
    public String toString() {
    return this.getNombreCompleto(); 
}
}
