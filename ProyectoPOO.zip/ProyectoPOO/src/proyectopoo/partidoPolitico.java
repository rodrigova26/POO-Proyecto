/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoo;

import java.io.Serializable;
import java.util.ArrayList;


public class partidoPolitico implements Serializable {
    private String nombre;
    private String sigla;
    private String representanteLegal;
    private static ArrayList<partidoPolitico> todosLosPartidos = new ArrayList<>();
    private ArrayList<Candidato> listaCandidatos = new ArrayList<>();

    public partidoPolitico(String nombre, String sigla, String representanteLegal) {
        this.nombre = nombre;
        this.sigla = sigla;
        this.representanteLegal = representanteLegal;
    }
    
    public ArrayList<Candidato> getListaCandidatos() {
        return listaCandidatos;
    }

    public void agregarCandidato(Candidato c) {
        this.listaCandidatos.add(c);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getSigla() {
        return sigla;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    public String getRepresentanteLegal() {
        return representanteLegal;
    }

    public void setRepresentanteLegal(String representanteLegal) {
        this.representanteLegal = representanteLegal;
    }
    
    public static ArrayList<partidoPolitico> getTodosLosPartidos() {
        return new ArrayList<>(todosLosPartidos);  // Copia defensiva
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        partidoPolitico that = (partidoPolitico) obj;
        return sigla != null && sigla.equals(that.sigla);
    }

    @Override
    public int hashCode() {
        return sigla != null ? sigla.hashCode() : 0;
    }

    @Override
    public String toString() {
    return this.nombre; // O como se llame el atributo del nombre
}
}
