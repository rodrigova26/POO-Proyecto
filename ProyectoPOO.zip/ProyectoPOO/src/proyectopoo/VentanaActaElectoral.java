/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyectopoo;

import Control.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Lenovo
 */
public class VentanaActaElectoral extends javax.swing.JFrame {
    private ControladorMiembroMesa controladorMiembroMesa;
    private ControladorEleccion controlador;
    private ControladorPartido controladorPartido;
    private ControladorCandidato controladorCandidato;
    private ControladorMesaElectoral controladorMesaElectoral;
    private ControladorActaElectoral controladorActaElectoral;
    
    private DefaultComboBoxModel modeloComboEleccion;
    private DefaultComboBoxModel modeloComboNombreMesa;
    private DefaultComboBoxModel modeloComboCandidato;
    
    
    private DefaultTableModel modeloTabla;
    private final String[] COLUMNAS = new String[]{
        "Candidato", "Votos"};
    
    private DefaultTableModel modeloTabla1;
    private final String[] COLUMNAS1 = new String[]{
        "Titulo", "Nmro de acta","Fecha","VotosTotales","Votosefectivos",};

    /**
     * Creates new form VentanaActaElectoral
     */
    public VentanaActaElectoral() {
        initComponents();
    }
    
    
    public VentanaActaElectoral(ControladorEleccion controladors,
    ControladorPartido controladorPartido,
    ControladorCandidato controladorCandidato,
    ControladorMiembroMesa controladorMiembroMesa,ControladorMesaElectoral controladorMesaElectoral, ControladorActaElectoral controladorActaElectoral) {
        initComponents();
        this.controlador = controladors;
        this.controladorPartido = controladorPartido;
        this.controladorCandidato = controladorCandidato;
        this.controladorMiembroMesa = controladorMiembroMesa;
        this.controladorActaElectoral = controladorActaElectoral;
        this.controladorMesaElectoral = controladorMesaElectoral;
        
        modeloComboEleccion = new DefaultComboBoxModel();
        this.cbxEleccion.setModel(modeloComboEleccion);
        
        modeloComboNombreMesa = new DefaultComboBoxModel();
        this.cbxNombreMesa.setModel(modeloComboNombreMesa);
        
        
        modeloComboCandidato = new DefaultComboBoxModel();
        this.cbxCandidatos.setModel(modeloComboCandidato);
        
        
        cbxEleccion.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            llenarNombreMesaEnCombo(); 
            llenarCandidatosEnCombo();
        }
    });
        
        
        this.llenarEleccionesEnCombo();
        this.llenarNombreMesaEnCombo();
        this.llenarCandidatosEnCombo();
        this.inicializarTablaCandidatos();
        this.actualizarTablaCandidatos();
        this.inicializarTablaActas();
        this.actualizarTablaActas();
        
    }
    
    
    private void llenarEleccionesEnCombo() {
        ArrayList<Eleccion> listaElecciones = controlador.getListaElecciones();
        for (Eleccion Eleccion : listaElecciones) {
            this.modeloComboEleccion.addElement(Eleccion);
        }
    }
    
    
    private void llenarNombreMesaEnCombo() {
        modeloComboNombreMesa.removeAllElements();

        Eleccion eleccionSeleccionada = (Eleccion) cbxEleccion.getSelectedItem();
        if (eleccionSeleccionada != null) {
            String nombreEleccionSeleccionada = eleccionSeleccionada.getNombre(); 

            for (MesaElectoral mesa : controladorMesaElectoral.getListaMesasElectorales()) {
                if (mesa.getEleccion().equals(nombreEleccionSeleccionada)) {
                    modeloComboNombreMesa.addElement(mesa.getNumerodeMesa());
                }
            }
        }
    }
    
    private void llenarCandidatosEnCombo() {
        modeloComboCandidato.removeAllElements();

        Eleccion eleccionSeleccionada = (Eleccion) cbxEleccion.getSelectedItem();

        if (eleccionSeleccionada != null) {
            ArrayList<Candidato> listaCandidatos = eleccionSeleccionada.getCandidatos();

            for (Candidato candidato : listaCandidatos) {
                modeloComboCandidato.addElement(candidato.getNombreCompleto());
            }
        }
    }
    private void inicializarTablaCandidatos() {
    String[] columnas = {"Votos", "Candidato"};
    modeloTabla = new DefaultTableModel(null, columnas);
    TablaCandidatos.setModel(modeloTabla);
}
    
    
    
    private void actualizarTablaCandidatos() {
    modeloTabla.setRowCount(0); // limpia la tabla

    for (Candidato candidato : controladorCandidato.getListaCandidatos()) {
        Object[] fila = {
            candidato.getNombreCompleto(),
            candidato.getVotosPreferenciales()
        };
        modeloTabla.addRow(fila);
    }
}
    
    
    private void inicializarTablaActas() {
    modeloTabla1 = new DefaultTableModel(null, COLUMNAS1);
    tblActasRegistradas.setModel(modeloTabla1);
}
    
    private void actualizarTablaActas() {
    String[] columnas = {"Título", "N° de Acta", "Fecha", "Votos Totales", "Votos Efectivos"};
    modeloTabla1 = new DefaultTableModel(null, columnas);

    for (ActaElectoral acta : controladorActaElectoral.getListaActasElectorales()) {
        Object[] fila = {
            acta.getTitulo(),
            acta.getNumeroActa(),
            new SimpleDateFormat("dd/MM/yyyy").format(acta.getFecha()),
            acta.getTotalVotantes(),
            acta.getVotosEfectivos()
        };
        modeloTabla1.addRow(fila);
    }

    tblActasRegistradas.setModel(modeloTabla1);
}
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        textTitulo = new javax.swing.JTextField();
        textFecha = new javax.swing.JTextField();
        textHora = new javax.swing.JTextField();
        textNumerodeActa = new javax.swing.JTextField();
        textLugar = new javax.swing.JTextField();
        textCantidadVotosNulos = new javax.swing.JTextField();
        textCantidadVotosBlanco = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        textCantidadVotosEmitidos = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblActasRegistradas = new javax.swing.JTable();
        jLabel12 = new javax.swing.JLabel();
        cbxNombreMesa = new javax.swing.JComboBox<>();
        botonRegistrar = new javax.swing.JButton();
        botonCancelar = new javax.swing.JButton();
        botonEliminar = new javax.swing.JButton();
        cbxCandidatos = new javax.swing.JComboBox<>();
        jScrollPane3 = new javax.swing.JScrollPane();
        TablaCandidatos = new javax.swing.JTable();
        jRVotos = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        cbxEleccion = new javax.swing.JComboBox<>();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("REGISTRO DE ACTA ELECTORAL");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setText("Datos de las Actas");

        jLabel3.setText("Título:");

        jLabel4.setText("Nombre de la mesa:");

        jLabel5.setText("Fecha");

        jLabel6.setText("Hora:");

        jLabel7.setText("Número de acta:");

        jLabel8.setText("Lugar:");

        jLabel9.setText("Cantidad de votos nulos:");

        jLabel10.setText("Cantidad de votos en blanco:");

        textTitulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textTituloActionPerformed(evt);
            }
        });

        textFecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textFechaActionPerformed(evt);
            }
        });

        textHora.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textHoraActionPerformed(evt);
            }
        });

        textNumerodeActa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textNumerodeActaActionPerformed(evt);
            }
        });

        textLugar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textLugarActionPerformed(evt);
            }
        });

        textCantidadVotosNulos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textCantidadVotosNulosActionPerformed(evt);
            }
        });

        textCantidadVotosBlanco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textCantidadVotosBlancoActionPerformed(evt);
            }
        });

        jLabel11.setText("Cantidad de votos para:");

        textCantidadVotosEmitidos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textCantidadVotosEmitidosActionPerformed(evt);
            }
        });

        tblActasRegistradas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tblActasRegistradas);

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel12.setText("Actas Registradas");

        cbxNombreMesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxNombreMesaActionPerformed(evt);
            }
        });

        botonRegistrar.setText("Registrar");
        botonRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonRegistrarActionPerformed(evt);
            }
        });

        botonCancelar.setText("Cancelar");
        botonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCancelarActionPerformed(evt);
            }
        });

        botonEliminar.setText("Eliminar");
        botonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarActionPerformed(evt);
            }
        });

        cbxCandidatos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxCandidatosActionPerformed(evt);
            }
        });

        TablaCandidatos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(TablaCandidatos);

        jRVotos.setText("Registro voto");
        jRVotos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRVotosActionPerformed(evt);
            }
        });

        jLabel13.setText("Eleccion");

        cbxEleccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxEleccionActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel10)
                                        .addGap(42, 42, 42)
                                        .addComponent(textCantidadVotosBlanco, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel7)
                                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel11)
                                            .addComponent(jLabel9)
                                            .addComponent(jLabel4))
                                        .addGap(65, 65, 65)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(cbxEleccion, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(cbxNombreMesa, 0, 191, Short.MAX_VALUE)
                                            .addComponent(textCantidadVotosNulos, javax.swing.GroupLayout.DEFAULT_SIZE, 191, Short.MAX_VALUE)
                                            .addComponent(textNumerodeActa)
                                            .addComponent(textLugar, javax.swing.GroupLayout.DEFAULT_SIZE, 191, Short.MAX_VALUE)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(textCantidadVotosEmitidos, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(cbxCandidatos, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jRVotos)
                                        .addGap(32, 32, 32)
                                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(botonRegistrar)
                                        .addGap(18, 18, 18)
                                        .addComponent(botonEliminar)
                                        .addGap(18, 18, 18)
                                        .addComponent(botonCancelar)))))
                        .addContainerGap(26, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 677, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(212, 212, 212)
                                .addComponent(jLabel1))
                            .addComponent(jLabel2)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(textTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(58, 58, 58)
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(textFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(80, 80, 80)
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(textHora, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(4, 4, 4)
                .addComponent(jLabel2)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(textTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(jLabel6)
                            .addComponent(textHora, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addGap(7, 7, 7))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(cbxEleccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4)
                            .addComponent(cbxNombreMesa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(textNumerodeActa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textLugar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(textCantidadVotosEmitidos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(cbxCandidatos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jRVotos))
                            .addComponent(jLabel11))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textCantidadVotosNulos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textCantidadVotosBlanco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10)
                            .addComponent(botonCancelar)
                            .addComponent(botonEliminar)
                            .addComponent(botonRegistrar))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(34, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(66, 66, 66)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cbxNombreMesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxNombreMesaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxNombreMesaActionPerformed

    private void textTituloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textTituloActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textTituloActionPerformed

    private void cbxCandidatosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxCandidatosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxCandidatosActionPerformed

    private void textFechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textFechaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textFechaActionPerformed

    private void textHoraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textHoraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textHoraActionPerformed

    private void textNumerodeActaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textNumerodeActaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textNumerodeActaActionPerformed

    private void textLugarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textLugarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textLugarActionPerformed

    private void textCantidadVotosEmitidosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textCantidadVotosEmitidosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textCantidadVotosEmitidosActionPerformed

    private void textCantidadVotosNulosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textCantidadVotosNulosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textCantidadVotosNulosActionPerformed

    private void textCantidadVotosBlancoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textCantidadVotosBlancoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textCantidadVotosBlancoActionPerformed

    private void botonRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonRegistrarActionPerformed
        try {
        String titulo = textTitulo.getText();
        String fechaStr = textFecha.getText();
        String hora = textHora.getText();
        String numeroActa = textNumerodeActa.getText();
        String lugar = textLugar.getText();
        int votosNulos = Integer.parseInt(textCantidadVotosNulos.getText());
        int votosBlanco = Integer.parseInt(textCantidadVotosBlanco.getText());
        int votosEfectivos = 0;

 
        String numeroMesa = (String) cbxNombreMesa.getSelectedItem();
        MesaElectoral mesaSeleccionada = null;
        for (MesaElectoral m : controladorMesaElectoral.getListaMesasElectorales()) {
            if (m.getNumerodeMesa().equals(numeroMesa)) {
                mesaSeleccionada = m;
                break;
            }
        }

        if (mesaSeleccionada == null) {
            JOptionPane.showMessageDialog(this, "Mesa no encontrada.");
            return;
        }


        Eleccion eleccion = (Eleccion) cbxEleccion.getSelectedItem();
        if (eleccion == null) {
            JOptionPane.showMessageDialog(this, "Seleccione una elección.");
            return;
        }

   
        ArrayList<Candidato> listaCandidatos = controladorCandidato.getListaCandidatos();
        for (Candidato c : listaCandidatos) {
            if (c.getEleccion().equals(eleccion.getNombre())) {
                votosEfectivos += c.getVotosPreferenciales();
            }
        }

        // Convertir fecha
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        Date fecha = formatoFecha.parse(fechaStr);

        // Crear acta
        ActaElectoral nuevaActa = new ActaElectoral(
            titulo,
            votosEfectivos + votosBlanco + votosNulos,
            votosEfectivos,
            votosNulos,
            votosBlanco,
            fecha,
            mesaSeleccionada,
            hora,
            numeroActa,
            eleccion.getNombre()
        );


        for (Candidato c : listaCandidatos) {
            if (c.getEleccion().equals(eleccion.getNombre())) {
                int votos = c.getVotosPreferenciales();
                if (votos > 0) {
                    nuevaActa.registrarVoto(c, votos);
                }
            }
        }

        controladorActaElectoral.agregar(nuevaActa);
        JOptionPane.showMessageDialog(this, "Acta registrada correctamente.");
        actualizarTablaActas();

    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this, "Ingrese números válidos en los campos de votos.");
    } catch (ParseException ex) {
        JOptionPane.showMessageDialog(this, "Formato de fecha incorrecto (use dd/MM/yyyy).");
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this, "Error al registrar acta: " + ex.getMessage());
        }
    }//GEN-LAST:event_botonRegistrarActionPerformed

    private void botonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarActionPerformed
        int filaSeleccionada = tblActasRegistradas.getSelectedRow();

        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un acta para eliminar.");
            return;
        }

       
        String numeroActa = (String) tblActasRegistradas.getValueAt(filaSeleccionada, 1);

       
        ActaElectoral actaAEliminar = null;
        for (ActaElectoral acta : controladorActaElectoral.getListaActasElectorales()) {
            if (acta.getNumeroActa().equals(numeroActa)) {
                actaAEliminar = acta;
                break;
            }
        }

        if (actaAEliminar != null) {
            controladorActaElectoral.eliminar(actaAEliminar);
            JOptionPane.showMessageDialog(this, "Acta eliminada correctamente.");
            actualizarTablaActas();
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo encontrar el acta.");
        }
    }//GEN-LAST:event_botonEliminarActionPerformed

    private void botonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCancelarActionPerformed
        // TODO add your handling code here:
        new VentanaMenu(controlador,
        controladorPartido,
        controladorCandidato,
        controladorMiembroMesa,controladorMesaElectoral,controladorActaElectoral).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_botonCancelarActionPerformed

    private void jRVotosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRVotosActionPerformed
        // TODO add your handling code here:
        String nombreCandidato = (String) cbxCandidatos.getSelectedItem();
        String textoVotos = textCantidadVotosEmitidos.getText();

        if (nombreCandidato == null || nombreCandidato.isEmpty() || textoVotos.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Seleccione un candidato e ingrese los votos.");
            return;
        }

        try {
            int cantidadVotos = Integer.parseInt(textoVotos);
            if (cantidadVotos < 0) {
                JOptionPane.showMessageDialog(this, "Los votos no pueden ser negativos.");
                return;
            }

            Candidato candidatoSeleccionado = null;
            for (Candidato c : controladorCandidato.getListaCandidatos()) {
                if (c.getNombreCompleto().equals(nombreCandidato)) {
                    candidatoSeleccionado = c;
                    break;
                }
            }

            if (candidatoSeleccionado != null) {
                for (int i = 0; i < cantidadVotos; i++) {
                    candidatoSeleccionado.registrarVotoPreferencial(); 
                }

                JOptionPane.showMessageDialog(this, "Se asignaron " + cantidadVotos + " votos a " + candidatoSeleccionado.getNombreCompleto());
                actualizarTablaCandidatos(); 
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró el candidato.");
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Cantidad de votos inválida.");
        }
    }//GEN-LAST:event_jRVotosActionPerformed

    private void cbxEleccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxEleccionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxEleccionActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaActaElectoral.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaActaElectoral.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaActaElectoral.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaActaElectoral.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Eleccion.cargarElecciones(); 
                ControladorEleccion controlador = new ControladorEleccion();
                ControladorPartido controladorPartido = new ControladorPartido();
                ControladorCandidato controladorCandidato = new ControladorCandidato();
                ControladorMiembroMesa controladorMiembroMesa = new ControladorMiembroMesa();
                ControladorMesaElectoral controladorMesaElectoral = new ControladorMesaElectoral();
                ControladorActaElectoral controladorActaElectoral = new ControladorActaElectoral();
            

            new VentanaElecciones(controlador, controladorPartido, controladorCandidato, controladorMiembroMesa,controladorMesaElectoral,controladorActaElectoral).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaCandidatos;
    private javax.swing.JButton botonCancelar;
    private javax.swing.JButton botonEliminar;
    private javax.swing.JButton botonRegistrar;
    private javax.swing.JComboBox<String> cbxCandidatos;
    private javax.swing.JComboBox<String> cbxEleccion;
    private javax.swing.JComboBox<String> cbxNombreMesa;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JButton jRVotos;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable tblActasRegistradas;
    private javax.swing.JTextField textCantidadVotosBlanco;
    private javax.swing.JTextField textCantidadVotosEmitidos;
    private javax.swing.JTextField textCantidadVotosNulos;
    private javax.swing.JTextField textFecha;
    private javax.swing.JTextField textHora;
    private javax.swing.JTextField textLugar;
    private javax.swing.JTextField textNumerodeActa;
    private javax.swing.JTextField textTitulo;
    // End of variables declaration//GEN-END:variables
}
