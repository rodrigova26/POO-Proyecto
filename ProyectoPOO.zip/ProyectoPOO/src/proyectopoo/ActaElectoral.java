/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoo;

import java.util.Date;

/**
 *
 * @author Rodrigo
 */
public class ActaElectoral {
    private String titulo;
    private Date fecha;
    private MesaElectoral mesa;
    private String Eleccion;
    private String hora;
    private String numeroActa;
    private int totalVotantes;
    private int votosEfectivos;
    private int votosNulos;
    private int votosBlanco;
    private Candidato[] candidatos;
    private int[] resultados;
    private int contador;

    public ActaElectoral(String titulo,int totalVotantes,int votosEfectivos,int votosNulos,int votosBlanco, Date fecha, MesaElectoral mesa, String hora, String numeroActa,String Eleccion) {
        this.titulo = titulo;
        this.fecha = fecha;
        this.mesa = mesa;
        this.hora = hora;
        this.Eleccion = Eleccion;
        this.numeroActa = numeroActa;
        this.candidatos = new Candidato[10];
        this.resultados = new int[10];
        this.contador = 0;
        this.totalVotantes = votosEfectivos + votosBlanco+ votosNulos;
        this.votosBlanco = votosBlanco;
        this.votosEfectivos = votosEfectivos;
        this.votosNulos = votosNulos;
    }

    public String getEleccion() {
        return Eleccion;
    }

    public void setEleccion(String Eleccion) {
        this.Eleccion = Eleccion;
    }
    
    
    

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getNumeroActa() {
        return numeroActa;
    }

    public void setNumeroActa(String numeroActa) {
        this.numeroActa = numeroActa;
    }
    
    
    
   
    public void registrarVoto(Candidato c, int cantidad) {
        for (int i = 0; i < contador; i++) {
            if (candidatos[i].equals(c)) {
                resultados[i] += cantidad;
                return;
            }
        }
        if (contador < candidatos.length) {
            candidatos[contador] = c;
            resultados[contador] = cantidad;
            contador++;
        }
    }

    public void setResumen(int total, int efectivos, int nulos, int blancos) {
        this.totalVotantes = total;
        this.votosEfectivos = efectivos;
        this.votosNulos = nulos;
        this.votosBlanco = blancos;
    }

    public String getNumero() {
        return titulo;
    }

    public void setNumero(String numero) {
        this.titulo = numero;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public MesaElectoral getMesa() {
        return mesa;
    }

    public void setMesa(MesaElectoral mesa) {
        this.mesa = mesa;
    }

    public int getTotalVotantes() {
        return totalVotantes;
    }

    public void setTotalVotantes(int totalVotantes) {
        this.totalVotantes = totalVotantes;
    }

    public int getVotosEfectivos() {
        return votosEfectivos;
    }

    public void setVotosEfectivos(int votosEfectivos) {
        this.votosEfectivos = votosEfectivos;
    }

    public int getVotosNulos() {
        return votosNulos;
    }

    public void setVotosNulos(int votosNulos) {
        this.votosNulos = votosNulos;
    }

    public int getVotosBlanco() {
        return votosBlanco;
    }

    public void setVotosBlanco(int votosBlanco) {
        this.votosBlanco = votosBlanco;
    }

    public Candidato[] getCandidatos() {
        return candidatos;
    }

    public void setCandidatos(Candidato[] candidatos) {
        this.candidatos = candidatos;
    }

    public int[] getResultados() {
        return resultados;
    }

    public void setResultados(int[] resultados) {
        this.resultados = resultados;
    }

    public int getContador() {
        return contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }
}