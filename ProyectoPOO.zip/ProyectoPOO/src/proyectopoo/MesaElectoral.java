/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoo;

/**
 *
 * @author Rodrigo
 */
public class MesaElectoral {
    private String lugar;
    private MiembroMesa[] miembros;
    private int contador;
    private String NumerodeMesa;
    private String Eleccion;

    public MesaElectoral(String lugar, String NumerodeMesa,String Eleccion) {
        this.lugar = lugar;
        this.miembros = new MiembroMesa[5];
        this.contador = 0;
        this.NumerodeMesa= NumerodeMesa;
        this.Eleccion = Eleccion;
    }
    
    public void asignarMiembro(MiembroMesa m) {
        if (contador < miembros.length) {
            miembros[contador] = m;
            contador++;
        }
    }

    public String getNumerodeMesa() {
        return NumerodeMesa;
    }

    public void setNumerodeMesa(String NumerodeMesa) {
        this.NumerodeMesa = NumerodeMesa;
    }

    public String getEleccion() {
        return Eleccion;
    }

    public void setEleccion(String Eleccion) {
        this.Eleccion = Eleccion;
    }
    
    
    

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public MiembroMesa[] getMiembros() {
        return miembros;
    }

    public void setMiembros(MiembroMesa[] miembros) {
        this.miembros = miembros;
    }

    public int getContador() {
        return contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }
    
    
}
