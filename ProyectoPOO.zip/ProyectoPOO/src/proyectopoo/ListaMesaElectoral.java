/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoo;

import java.util.ArrayList;

/**
 *
 * @author Carlos
 */
public class ListaMesaElectoral {
    private ArrayList<MesaElectoral> array;

    public ListaMesaElectoral() {
        this.array = new ArrayList<MesaElectoral>();
    }
    
    public boolean agregar(MesaElectoral MesaElectoral) {
        this.array.add(MesaElectoral);
        return true;
    }
    
    public boolean eliminar(MesaElectoral MesaElectoral) {
        return this.array.remove(MesaElectoral);
    }
    

    public ArrayList<MesaElectoral> getListaMesaElectoral() {
        if (array.isEmpty()) {
            return array;
        }

        
        ArrayList<MesaElectoral> copia = new ArrayList<MesaElectoral>();

        
        for (int i = 0; i < array.size(); i++) {
            copia.add(array.get(i)); 
        }

        return copia;
    }
}
