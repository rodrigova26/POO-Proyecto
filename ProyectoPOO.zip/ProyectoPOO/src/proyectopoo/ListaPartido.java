/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoo;

import java.util.ArrayList;

/**
 *
 * @author Carlos
 */
public class ListaPartido {
    private ArrayList<partidoPolitico> array;

    public ListaPartido() {
        this.array = new ArrayList<partidoPolitico>();
    }
    
    public boolean agregar(partidoPolitico partidoPolitico) {
        this.array.add(partidoPolitico);
        return true;
    }
    
    public boolean eliminar(partidoPolitico partidoPolitico) {
        return this.array.remove(partidoPolitico);
    }
    

    public ArrayList<partidoPolitico> getListaPartidos() {
        if (array.isEmpty()) {
            return array;
        }

        
        ArrayList<partidoPolitico> copia = new ArrayList<partidoPolitico>();

  
        for (int i = 0; i < array.size(); i++) {
            copia.add(array.get(i)); 
        }

        return copia;
    }
}

