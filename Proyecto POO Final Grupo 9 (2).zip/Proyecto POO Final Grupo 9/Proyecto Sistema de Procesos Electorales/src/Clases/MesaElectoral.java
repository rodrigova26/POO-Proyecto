/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;
import java.util.Scanner;

public class MesaElectoral {

    private MiembroMesa[][] arregloMiembros;   
    private String idMesa;
    private int cantidadMesas;  
    private static final int MAX = 10;  
    private static final int MAX_MIEMBROS = 3;  


    public MesaElectoral() {
        idMesa = "";
        cantidadMesas = 0;

        arregloMiembros = new MiembroMesa[MAX][MAX_MIEMBROS]; 
    }


    public MesaElectoral(String idMesa) {
        this.idMesa = idMesa;

        this.cantidadMesas = 0;
        arregloMiembros = new MiembroMesa[MAX][MAX_MIEMBROS]; 
    }

 
    public String getIdMesa() {
        return idMesa;
    }

    public void setIdMesa(String idMesa) {
        this.idMesa = idMesa;
    }



    public MiembroMesa[][] getArregloMiembros() {
        return arregloMiembros;
    }

    public int getCantidadMesas() {
        return cantidadMesas;
    }

  
    public void agregarMesasPorTeclado() {
        Scanner scanner = new Scanner(System.in);


        for (int i = 0; i < MAX; i++) {
            System.out.println("Ingrese los datos para la mesa #" + (i + 1));

            MiembroMesa[] miembrosMesa = new MiembroMesa[MAX_MIEMBROS];
            for (int j = 0; j < MAX_MIEMBROS; j++) {
                System.out.println("Miembro #" + (j + 1));
                miembrosMesa[j] = MiembroMesa.crearMiembro(); 
            }
            
            agregarMesa(miembrosMesa);
            
            System.out.print("¿Desea agregar otra mesa? (s/n): ");
            String respuesta = scanner.nextLine();
            if (respuesta.equalsIgnoreCase("n")) {
                break;
            }
        }
    }


    public void agregarMesa(MiembroMesa[] miembrosMesa) {
        if (cantidadMesas < MAX) {
            arregloMiembros[cantidadMesas] = miembrosMesa;  
            cantidadMesas++;
        } else {
            System.out.println("No se pueden agregar más mesas. Limite alcanzado de " + MAX + " mesas.");
        }
    }


    public void verInfo() {
        System.out.println("Mesas del sistema:");
        for (int i = 0; i < cantidadMesas; i++) {
            System.out.println("Mesa #" + (i + 1) + " - ID: " + idMesa + ", Fecha: " );
            System.out.println("Miembros asignados:");
            for (int j = 0; j < MAX_MIEMBROS; j++) {
                arregloMiembros[i][j].verInfo(); 
            }
        }
    }
}
