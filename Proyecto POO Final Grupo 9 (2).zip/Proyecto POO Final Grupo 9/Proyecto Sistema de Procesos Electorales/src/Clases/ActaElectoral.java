/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import java.util.Scanner;

public class ActaElectoral {

    // Atributos básicos de un acta electoral
    private String numeroActa;                          
    private String idMesa;                    
    private int totalVotosEmitidos;           
    private int totalVotosBlanco;             
    private int totalVotosNulos;            
    private String observaciones;             

    // Arrays para manejar candidatos y sus votos
    private Candidato[] candidatos;           
    private int[] votosCandidatos;            

    // Constantes y estructura para votos preferenciales
    private final int MAX_PREFERENCIAS = 3;   
    private final int MAX_VOTANTES = 100;     
    private int[][] votosPreferenciales = new int[MAX_VOTANTES][MAX_PREFERENCIAS]; 
    private int contadorVotantesPreferenciales = 0; 

    private Eleccion eleccion;                
    Scanner sc = new Scanner(System.in);     


    public ActaElectoral() {
        this.eleccion = new Eleccion();
        this.eleccion.registrarCandidato();  
        this.mostrarCandidatos();           
      
        this.numeroActa = "";
        this.idMesa = "";
        this.totalVotosEmitidos = 0;
        this.totalVotosBlanco = 0;
        this.totalVotosNulos = 0;
        this.observaciones = "";
    }


    public ActaElectoral(String numeroActa, String idMesa, int totalVotosEmitidos, int totalVotosBlanco,
                         int totalVotosNulos, String observaciones, Candidato[] candidatos, int[] votosCandidatos) {

        this.numeroActa = numeroActa;
        this.idMesa = idMesa;
        this.totalVotosEmitidos = totalVotosEmitidos;
        this.totalVotosBlanco = totalVotosBlanco;
        this.totalVotosNulos = totalVotosNulos;
        this.observaciones = observaciones;
        this.candidatos = candidatos;
        this.votosCandidatos = new int[candidatos.length]; 
    }


    public void registrarVotos() {


        Candidato[] candidatosEleccion = eleccion.getCandidatos();

 
        if (candidatosEleccion.length == 0) {
            System.out.println("Error: Aún no hay candidatos registrados.");
            return;
        }

 
        System.out.println("------ REGISTRAR VOTOS ------");
        System.out.println("Por favor seleccione el candidato para registrar sus votos:");

        for (int i = 0; i < candidatosEleccion.length; i++) {
            if (candidatosEleccion[i] != null) {
                System.out.println((i + 1) + ". " + candidatosEleccion[i].getNombre() + " " + candidatosEleccion[i].getApellido() + 
                                   " - DNI: " + candidatosEleccion[i].getDni());
            }
        }


        System.out.print("Ingrese el número del candidato (1 - " + candidatosEleccion.length + "): ");
        int option = sc.nextInt();


        if (option < 1 || option > candidatosEleccion.length) {
            System.out.println("Error: opción inválida.");
            return;
        }


        int candidatoIndex = option - 1;
        Candidato candidatoSeleccionado = candidatosEleccion[candidatoIndex];

   
        System.out.print("Ingrese la cantidad de votos para " + candidatoSeleccionado.getNombre() + ": ");
        int votos = sc.nextInt();

  
        if (votos < 1) {
            System.out.println("Error: un candidato debe tener al menos 1 voto.");
            return;
        }

  
        votosCandidatos[candidatoIndex] += votos;
        totalVotosEmitidos += votos;


        System.out.println("Votos registrados correctamente para " + candidatoSeleccionado.getNombre() + ".");
        System.out.println("Total de votos para " + candidatoSeleccionado.getNombre() + " " + candidatoSeleccionado.getApellido() + 
                           ": " + votosCandidatos[candidatoIndex]);
        System.out.println("Total de votos emitidos (incluye blancos y nulos): " + (totalVotosEmitidos + totalVotosBlanco + totalVotosNulos));
    }

 
    public Candidato[] getCandidatos() {
        return eleccion != null ? eleccion.getCandidatos() : new Candidato[0];
    }

    public void mostrarCandidatos() {
        for (Candidato c : getCandidatos()) {
            if (c != null) {
                System.out.println(c.getNombre() + " " + c.getApellido());
            }
        }
    }
}
