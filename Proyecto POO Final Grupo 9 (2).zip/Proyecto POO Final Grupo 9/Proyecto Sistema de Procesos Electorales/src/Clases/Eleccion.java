/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import java.util.Scanner;

public class Eleccion {
    Scanner sc = new Scanner(System.in);

    private final int MAXpartidos = 20;
    private final int MAXactas =10;
    private final int MAXcandidatos = 20;  
    
    
    private String codigo;
    private String tipo;
    private String descripcion;

    private PartidoPolitico[] partidos;
    private int cantidadPartidos;

    private Candidato[] candidatos;
    private int cantidadCandidatos;

    private MesaElectoral[] miembros;
    private int cantidadMiembros;

    private ActaElectoral[] arregloActas;
    private int cantidadActas = 0 ; 

    private int[] votosCandidatos; 


    public Eleccion() {
        codigo = "00000";
        tipo = "";
        descripcion = "";


        partidos = new PartidoPolitico[MAXpartidos];
        cantidadPartidos = 0;

        candidatos = new Candidato[0];
        cantidadCandidatos = 0;

        miembros = new MesaElectoral[20];
        cantidadMiembros = 0;

        arregloActas = new ActaElectoral[MAXactas];
    }

    public Eleccion(String codigo, String tipo, String descripcion, PartidoPolitico[] partidos, int cantidadPartidos, Candidato[] candidatos, int cantidadCandidatos, MesaElectoral[] miembros, int cantidadMiembros) {
        this.codigo = codigo;
        this.tipo = tipo;
        this.descripcion = descripcion;
        this.partidos = partidos;
        this.cantidadPartidos = cantidadPartidos;
        this.candidatos = candidatos;
        this.cantidadCandidatos = cantidadCandidatos;
        this.miembros = miembros;
        this.cantidadMiembros = cantidadMiembros;
    }


    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }


    public PartidoPolitico[] getPartidos() {
        return partidos;
    }

    public void setPartidos(PartidoPolitico[] partidos) {
        this.partidos = partidos;
    }

    public int getCantidadPartidos() {
        return cantidadPartidos;
    }

    public void setCantidadPartidos(int cantidadPartidos) {
        this.cantidadPartidos = cantidadPartidos;
    }

    public Candidato[] getCandidatos() {
        return candidatos;
    }

    public void setCandidatos(Candidato[] candidatos) {
        this.candidatos = candidatos;
    }

    public int getCantidadCandidatos() {
        return cantidadCandidatos;
    }

    public void setCantidadCandidatos(int cantidadCandidatos) {
        this.cantidadCandidatos = cantidadCandidatos;
    }

    public MesaElectoral[] getMiembros() {
        return miembros;
    }

    public void setMiembros(MesaElectoral[] miembros) {
        this.miembros = miembros;
    }

    public int getCantidadMiembros() {
        return cantidadMiembros;
    }

    public void setCantidadMiembros(int cantidadMiembros) {
        this.cantidadMiembros = cantidadMiembros;
    }
    
    public void registrarActa(){
        int canrtidadActas = 0;

        if (cantidadActas>= MAXactas) {
            System.out.println("Se superó el numero de actas posibles ");
            return;
        }
        System.out.println("Ingrese el numero de acta: ");
        String nroacta = sc.nextLine();
  


        //ID DE LA MESA
        System.out.println("Ingrese ID de la mesa : ");
        String idMesa = sc.nextLine();
        //NUMERO DE VOTOS 
        System.out.println("Ingrese el numero de votos total : ");
        int totalVotos = sc.nextInt();
        System.out.println("Ingrese el numero de votos en blanco : ");
        int votosBlanco = sc.nextInt();
        System.out.println("Ingrese el numero de votos en NULOS : ");
        int totalVotosNulos = sc.nextInt();
        //AGREGAR OBSERVACIONES AL ACTA 
        System.out.println("Agregar obeservaciones: ");
        String obs = sc.nextLine();

        sc.nextLine(); //LIMPIAR BUFFER

        ActaElectoral nuevaActa = new ActaElectoral(nroacta, idMesa, totalVotos, votosBlanco, totalVotosNulos, obs , getCandidatos(), new int[getCandidatos().length] );
        
        //GUARDAR EL NUEVO ACTA REGISTRADO EN EL ARRAY 
        arregloActas[cantidadActas] = nuevaActa;
        canrtidadActas ++;
        System.out.println("Se registró el acta correctamente ");



        
    }
    // REGISTRAR PARTIDO
    public void registrarPartido() {
        if (cantidadPartidos >= MAXpartidos) {
            System.out.println("⚠ No se pueden registrar más partidos (límite alcanzado).");
            return;
        }

        System.out.println("=== REGISTRO DE PARTIDO POLÍTICO ===");

        System.out.print("Nombre del partido: ");
        String nombre = sc.nextLine();

        System.out.print("Sigla del partido: ");
        String sigla = sc.nextLine();

        System.out.print("Nombre del representante legal: ");
        String nombreRep = sc.nextLine();

        System.out.print("Apellido del representante legal: ");
        String apellidoRep = sc.nextLine();

        System.out.print("DNI del representante legal: ");
        String dniRep = sc.nextLine();

        Persona representante = new Persona(nombreRep, apellidoRep, dniRep);
        PartidoPolitico nuevoPartido = new PartidoPolitico(nombre, sigla, representante);

        partidos[cantidadPartidos] = nuevoPartido;
        cantidadPartidos++;

        System.out.println("✅ Partido registrado correctamente.\n");
    }

    // REGISTRAR CANDIDATO
    public void registrarCandidato() {
        if (cantidadPartidos == 0) {
            System.out.println("⚠ No hay partidos registrados. Registre uno primero.");
            return;
        }

        System.out.println("=== REGISTRO DE CANDIDATO ===");

        System.out.print("Nombre del candidato: ");
        String nombre = sc.nextLine();

        System.out.print("Apellido del candidato: ");
        String apellido = sc.nextLine();

        System.out.print("DNI del candidato: ");
        String dni = sc.nextLine();

        System.out.println("Seleccione un partido:");
        for (int i = 0; i < cantidadPartidos; i++) {
            System.out.println((i + 1) + ". " + partidos[i].getNombre());
        }

        System.out.print("Opción: ");
        int opcion = Integer.parseInt(sc.nextLine()) - 1;

        if (opcion < 0 || opcion >= cantidadPartidos) {
            System.out.println("⚠ Opción inválida.");
            return;
        }

        PartidoPolitico partidoSeleccionado = partidos[opcion];
        Candidato nuevo = new Candidato(nombre, apellido, dni, partidoSeleccionado);

        aumentarTamanoCandidatos();
        candidatos[cantidadCandidatos] = nuevo;
        cantidadCandidatos++;

        System.out.println("✅ Candidato registrado con éxito.\n");
        nuevo.verInfo();
    }

    // MÉTODO PARA MOSTRAR CANDIDATOS
    public void mostrarCandidatos() {
        System.out.println("\n=== LISTA DE CANDIDATOS REGISTRADOS ===");
        for (int i = 0; i < cantidadCandidatos; i++) {
            System.out.println("Candidato " + (i + 1) + ":");
            candidatos[i].verInfo();
            System.out.println();
        }
    }

    // MÉTODO PARA AUMENTAR EL TAMAÑO DEL ARRAY DE CANDIDATOS
    private void aumentarTamanoCandidatos() {
        Candidato[] nuevo = new Candidato[candidatos.length + 1];
        for (int i = 0; i < candidatos.length; i++) {
            nuevo[i] = candidatos[i];
        }
        candidatos = nuevo;
    }

    public void mostrarVotosPorCandidato() {
        // Verificar si hay candidatos registrados
        if (cantidadCandidatos == 0) {
            System.out.println("⚠ No hay candidatos registrados.");
            return;
        }

        // Variable para el total de votos
        int totalVotos = 0;

        // Mostrar los votos por cada candidato
        System.out.println("=== VOTOS POR CANDIDATO ===");
        for (int i = 0; i < cantidadCandidatos; i++) {
            Candidato candidato = candidatos[i];
            int votos = votosCandidatos[i]; // Votos registrados para este candidato
            totalVotos += votos; // Sumar los votos al total

            // Mostrar información del candidato y sus votos
            System.out.println(candidato.getNombre() + " " + candidato.getApellido() + " - Votos: " + votos);
        }

        // Mostrar el total de votos emitidos
        System.out.println("\n=== VOTO TOTAL ===");
        System.out.println("Total de votos emitidos: " + totalVotos);
    }
    
}
